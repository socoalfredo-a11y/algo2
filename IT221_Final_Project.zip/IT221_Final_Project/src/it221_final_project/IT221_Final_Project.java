/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package it221_final_project;
import javax.swing.SwingUtilities;
/**
 *
 * @author darbe_yhgakvp
 */
public class IT221_Final_Project {

    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Index().setVisible(true);
        });
    }
    
}
