package it221_final_project;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class Inventory extends JFrame {

    // ===== COLOR PALETTE (matches Dashboard.java) =====
    private static final Color SIDEBAR_BG    = new Color(15, 23, 42);
    private static final Color SIDEBAR_HOVER = new Color(30, 41, 59);
    private static final Color ACTIVE_BTN    = new Color(79, 70, 229);
    private static final Color BODY_BG       = new Color(223, 232, 242);
    private static final Color CARD_BG       = Color.WHITE;
    private static final Color BORDER_COLOR  = new Color(238, 242, 246);
    private static final Color TEXT_MUTED    = new Color(100, 116, 139);
    private static final Color TEXT_DARK     = new Color(30, 41, 59);

    private static final Color COL_PURPLE    = new Color(79, 70, 229);
    private static final Color COL_GREEN     = new Color(34, 197, 94);
    private static final Color COL_YELLOW    = new Color(234, 179, 8);
    private static final Color COL_RED       = new Color(239, 68, 68);

    public Inventory() {
        createUI();
    }

    private void createUI() {
        setTitle("EventRides PH | Item Management");
        setSize(1280, 760);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(BODY_BG);

        add(buildSidebar(), BorderLayout.WEST);
        add(buildMainContent(), BorderLayout.CENTER);

        setVisible(true);
    }

    // ==============================================
    // SIDEBAR  (copied structure from Dashboard.java)
    // ==============================================
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(null);
        sidebar.setPreferredSize(new Dimension(240, 760));
        sidebar.setBackground(SIDEBAR_BG);

        // Brand
        JLabel brand = new JLabel("⬡  EventRides PH");
        brand.setBounds(20, 28, 200, 30);
        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("Segoe UI", Font.BOLD, 16));
        sidebar.add(brand);

        // Divider
        JSeparator sep = new JSeparator();
        sep.setBounds(20, 68, 200, 1);
        sep.setForeground(new Color(30, 41, 59));
        sidebar.add(sep);

        // Nav items — Inventory is active
        String[][] menu = {
            {"Dashboard", "▣"},
            {"Rentals",   "◫"},
            {"Inventory", "▤"},
            {"Customers", "◉"},
            {"Payments",  "▦"},
            {"Settings",  "⚙"},
        };

        int y = 90;
        for (String[] item : menu) {
            JButton btn = createNavButton(item[1] + "  " + item[0], item[0].equals("Inventory"));
            btn.setBounds(16, y, 208, 42);
            String dest = item[0];
            btn.addActionListener(e -> navigateTo(dest));
            sidebar.add(btn);
            y += 50;
        }

        // User card at bottom
        JPanel userCard = new JPanel(null);
        userCard.setBounds(16, 650, 208, 60);
        userCard.setBackground(new Color(30, 41, 59));
        userCard.setBorder(BorderFactory.createLineBorder(new Color(51, 65, 85), 1));

        JLabel avatar = new JLabel("SU", SwingConstants.CENTER);
        avatar.setBounds(10, 10, 38, 38);
        avatar.setBackground(COL_PURPLE);
        avatar.setOpaque(true);
        avatar.setForeground(Color.WHITE);
        avatar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        avatar.setBorder(new RoundBorder(19, COL_PURPLE));
        userCard.add(avatar);

        JLabel uName = new JLabel("System User");
        uName.setBounds(56, 10, 140, 18);
        uName.setForeground(Color.WHITE);
        uName.setFont(new Font("Segoe UI", Font.BOLD, 12));
        userCard.add(uName);

        JLabel uRole = new JLabel("Administrator");
        uRole.setBounds(56, 30, 140, 16);
        uRole.setForeground(new Color(148, 163, 184));
        uRole.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        userCard.add(uRole);

        sidebar.add(userCard);

        // Logout button
        JButton logoutBtn = new JButton("⏻  Log Out");
        logoutBtn.setBounds(16, 620, 208, 38);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorderPainted(false);
        logoutBtn.setBackground(new Color(127, 29, 29));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        logoutBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { logoutBtn.setBackground(COL_RED); }
            public void mouseExited(MouseEvent e)  { logoutBtn.setBackground(new Color(127, 29, 29)); }
        });
        logoutBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to log out?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new Index();
            }
        });
        sidebar.add(logoutBtn);

        return sidebar;
    }

    private JButton createNavButton(String label, boolean active) {
        JButton btn = new JButton(label);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setForeground(active ? Color.WHITE : new Color(148, 163, 184));
        btn.setBackground(active ? ACTIVE_BTN : SIDEBAR_BG);
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (!active) { btn.setBackground(SIDEBAR_HOVER); btn.setForeground(Color.WHITE); }
            }
            public void mouseExited(MouseEvent e) {
                if (!active) { btn.setBackground(SIDEBAR_BG); btn.setForeground(new Color(148, 163, 184)); }
            }
        });
        return btn;
    }

    // ==============================================
    // MAIN CONTENT
    // ==============================================
    private JScrollPane buildMainContent() {
        JPanel content = new JPanel();
        content.setLayout(null);
        content.setBackground(BODY_BG);
        content.setPreferredSize(new Dimension(1040, 900));

        // ---- HEADER ----
        JLabel title = new JLabel("Item Management");
        title.setBounds(30, 24, 500, 30);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(TEXT_DARK);
        content.add(title);

        JLabel subtitle = new JLabel("Maintain your fleet and equipment inventory.");
        subtitle.setBounds(30, 54, 500, 18);
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(TEXT_MUTED);
        content.add(subtitle);

        // ---- STAT CARDS ----
        content.add(buildStatCard("Total Assets",    "0", COL_PURPLE, "▤",  30,  90));
        content.add(buildStatCard("Available Fleet", "0", COL_GREEN,  "⬡", 270,  90));
        content.add(buildStatCard("Low Stock",       "0", COL_RED,    "⚠", 510,  90));
        content.add(buildStatCard("In Maintenance",  "0", COL_YELLOW, "⚙", 750,  90));

        // ---- FILTER BAR ----
        JPanel filterBar = buildFilterBar();
        filterBar.setBounds(30, 230, 970, 58);
        content.add(filterBar);

        // ---- VEHICLES SECTION ----
        content.add(buildSectionLabel("VEHICLES", 30, 310));
        content.add(buildEmptyState("⬡", "No vehicles registered yet.", 30, 338, 970, 110));

        // ---- EQUIPMENT SECTION ----
        content.add(buildSectionLabel("EVENT EQUIPMENT", 30, 468));
        content.add(buildEmptyState("▤", "No equipment items registered yet.", 30, 496, 970, 110));

        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        return scrollPane;
    }

    // ==============================================
    // STAT CARD  (matches Dashboard.java style)
    // ==============================================
    private JPanel buildStatCard(String title, String value, Color accent, String icon, int x, int y) {
        JPanel card = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBounds(x, y, 220, 120);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setBounds(16, 16, 150, 18);
        titleLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        titleLbl.setForeground(TEXT_MUTED);

        JLabel valueLbl = new JLabel(value);
        valueLbl.setBounds(16, 44, 150, 36);
        valueLbl.setFont(new Font("Segoe UI", Font.BOLD, 28));
        valueLbl.setForeground(accent);

        JLabel iconLbl = new JLabel(icon, SwingConstants.CENTER);
        iconLbl.setBounds(162, 14, 44, 44);
        iconLbl.setBackground(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 30));
        iconLbl.setForeground(accent);
        iconLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        iconLbl.setOpaque(true);

        JPanel bar = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(accent);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 4, 4);
                g2.dispose();
            }
        };
        bar.setOpaque(false);
        bar.setBounds(16, 96, 60, 4);

        card.add(titleLbl);
        card.add(valueLbl);
        card.add(iconLbl);
        card.add(bar);
        return card;
    }

    // ==============================================
    // FILTER BAR
    // ==============================================
    private JPanel buildFilterBar() {
        JPanel bar = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
                g2.dispose();
            }
        };
        bar.setOpaque(false);

        // Search field
        JTextField search = new JTextField("Search items...");
        search.setBounds(14, 12, 220, 34);
        search.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        search.setForeground(TEXT_MUTED);
        search.setBorder(BorderFactory.createCompoundBorder(
            new RoundedBorder(10, BORDER_COLOR),
            BorderFactory.createEmptyBorder(4, 10, 4, 10)));
        bar.add(search);

        // Filter pills
        String[] filters = {"All Items", "Vehicles", "Equipment"};
        int fx = 248;
        for (String f : filters) {
            boolean isFirst = f.equals("All Items");
            JButton pill = new JButton(f);
            pill.setBounds(fx, 12, 100, 34);
            pill.setFocusPainted(false);
            pill.setCursor(new Cursor(Cursor.HAND_CURSOR));
            pill.setFont(new Font("Segoe UI", Font.BOLD, 12));
            pill.setBorderPainted(false);
            if (isFirst) {
                pill.setBackground(ACTIVE_BTN);
                pill.setForeground(Color.WHITE);
            } else {
                pill.setBackground(new Color(241, 245, 249));
                pill.setForeground(TEXT_DARK);
            }
            bar.add(pill);
            fx += 110;
        }

        // Add New Item button
        JButton addBtn = new JButton("＋  Add New Item");
        addBtn.setBounds(800, 12, 156, 34);
        addBtn.setFocusPainted(false);
        addBtn.setBorderPainted(false);
        addBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        addBtn.setBackground(ACTIVE_BTN);
        addBtn.setForeground(Color.WHITE);
        addBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        addBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { addBtn.setBackground(new Color(67, 56, 202)); }
            public void mouseExited(MouseEvent e)  { addBtn.setBackground(ACTIVE_BTN); }
        });
        bar.add(addBtn);

        return bar;
    }

    // ==============================================
    // SECTION LABEL  (same style as Dashboard.java buildSectionLabel)
    // ==============================================
    private JLabel buildSectionLabel(String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y, 700, 20);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lbl.setForeground(TEXT_MUTED);
        return lbl;
    }

    // ==============================================
    // EMPTY STATE PANEL
    // ==============================================
    private JPanel buildEmptyState(String icon, String message, int x, int y, int w, int h) {
        JPanel panel = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);

                // Dashed border
                g2.setColor(new Color(203, 213, 225));
                float[] dash = {6f, 4f};
                g2.setStroke(new java.awt.BasicStroke(1.5f, java.awt.BasicStroke.CAP_BUTT,
                    java.awt.BasicStroke.JOIN_MITER, 10f, dash, 0f));
                g2.drawRoundRect(1, 1, getWidth() - 2, getHeight() - 2, 14, 14);
                g2.dispose();
            }
        };
        panel.setOpaque(false);
        panel.setBounds(x, y, w, h);

        JLabel iconLbl = new JLabel(icon, SwingConstants.CENTER);
        iconLbl.setBounds(0, 12, w, 30);
        iconLbl.setFont(new Font("Segoe UI", Font.BOLD, 22));
        iconLbl.setForeground(new Color(148, 163, 184));
        panel.add(iconLbl);

        JLabel msgLbl = new JLabel(message, SwingConstants.CENTER);
        msgLbl.setBounds(0, 50, w, 20);
        msgLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        msgLbl.setForeground(TEXT_MUTED);
        panel.add(msgLbl);

        return panel;
    }

    // ==============================================
    // NAVIGATION (unchanged)
    // ==============================================
    private void navigateTo(String destination) {
        this.dispose();
        switch (destination) {
            case "Dashboard": new Dashboard(); break;
            case "Rentals":   new Rentals();   break;
            case "Inventory": new Inventory(); break;
            case "Customers": new Customers(); break;
            case "Payments":  new Payments();  break;
            case "Settings":  new Settings();  break;
        }
    }

    // ==============================================
    // CUSTOM BORDER HELPERS (same as Dashboard.java)
    // ==============================================
    static class RoundedBorder extends AbstractBorder {
        private int radius;
        private Color color;
        RoundedBorder(int radius, Color color) { this.radius = radius; this.color = color; }
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.drawRoundRect(x, y, w - 1, h - 1, radius, radius);
            g2.dispose();
        }
        public Insets getBorderInsets(Component c) { return new Insets(radius + 1, radius + 1, radius + 1, radius + 1); }
    }

    static class RoundBorder extends AbstractBorder {
        private int arc;
        private Color color;
        RoundBorder(int arc, Color color) { this.arc = arc; this.color = color; }
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.drawOval(x, y, w - 1, h - 1);
            g2.dispose();
        }
    }
}