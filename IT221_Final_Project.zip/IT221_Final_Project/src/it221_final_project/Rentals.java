package it221_final_project;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

public class Rentals extends JFrame {

    // ===== COLOR PALETTE (matches Dashboard.java) =====
    private static final Color SIDEBAR_BG    = new Color(15, 23, 42);
    private static final Color SIDEBAR_HOVER = new Color(30, 41, 59);
    private static final Color ACTIVE_BTN    = new Color(79, 70, 229);
    private static final Color BODY_BG       = new Color(223, 232, 242);
    private static final Color CARD_BG       = Color.WHITE;
    private static final Color BORDER_COLOR  = new Color(238, 242, 246);
    private static final Color TEXT_MUTED    = new Color(100, 116, 139);
    private static final Color TEXT_DARK     = new Color(30, 41, 59);

    private static final Color COL_PURPLE    = new Color(79, 70, 229);
    private static final Color COL_GREEN     = new Color(34, 197, 94);
    private static final Color COL_YELLOW    = new Color(234, 179, 8);
    private static final Color COL_BLUE      = new Color(14, 165, 233);
    private static final Color COL_RED       = new Color(239, 68, 68);

    public Rentals() {
        createUI();
    }

    private void createUI() {
        setTitle("EventRides PH | Rental Management");
        setSize(1280, 760);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(BODY_BG);

        add(buildSidebar(), BorderLayout.WEST);
        add(buildMainContent(), BorderLayout.CENTER);

        setVisible(true);
    }

    // ==============================================
    // SIDEBAR  (identical structure to Dashboard.java)
    // ==============================================
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(null);
        sidebar.setPreferredSize(new Dimension(240, 760));
        sidebar.setBackground(SIDEBAR_BG);

        // Brand
        JLabel brand = new JLabel("⬡  EventRides PH");
        brand.setBounds(20, 28, 200, 30);
        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("Segoe UI", Font.BOLD, 16));
        sidebar.add(brand);

        // Divider
        JSeparator sep = new JSeparator();
        sep.setBounds(20, 68, 200, 1);
        sep.setForeground(new Color(30, 41, 59));
        sidebar.add(sep);

        // Nav items — Rentals is active
        String[][] menu = {
            {"Dashboard", "▣"},
            {"Rentals",   "◫"},
            {"Inventory", "▤"},
            {"Customers", "◉"},
            {"Payments",  "▦"},
            {"Settings",  "⚙"},
        };

        int y = 90;
        for (String[] item : menu) {
            JButton btn = createNavButton(item[1] + "  " + item[0], item[0].equals("Rentals"));
            btn.setBounds(16, y, 208, 42);
            String dest = item[0];
            btn.addActionListener(e -> navigateTo(dest));
            sidebar.add(btn);
            y += 50;
        }

        // User card at bottom
        JPanel userCard = new JPanel(null);
        userCard.setBounds(16, 650, 208, 60);
        userCard.setBackground(new Color(30, 41, 59));
        userCard.setBorder(BorderFactory.createLineBorder(new Color(51, 65, 85), 1));

        JLabel avatar = new JLabel("SU", SwingConstants.CENTER);
        avatar.setBounds(10, 10, 38, 38);
        avatar.setBackground(COL_PURPLE);
        avatar.setOpaque(true);
        avatar.setForeground(Color.WHITE);
        avatar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        avatar.setBorder(new RoundBorder(19, COL_PURPLE));
        userCard.add(avatar);

        JLabel uName = new JLabel("System User");
        uName.setBounds(56, 10, 140, 18);
        uName.setForeground(Color.WHITE);
        uName.setFont(new Font("Segoe UI", Font.BOLD, 12));
        userCard.add(uName);

        JLabel uRole = new JLabel("Administrator");
        uRole.setBounds(56, 30, 140, 16);
        uRole.setForeground(new Color(148, 163, 184));
        uRole.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        userCard.add(uRole);

        sidebar.add(userCard);

        // Logout button
        JButton logoutBtn = new JButton("⏻  Log Out");
        logoutBtn.setBounds(16, 620, 208, 38);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorderPainted(false);
        logoutBtn.setBackground(new Color(127, 29, 29));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        logoutBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { logoutBtn.setBackground(COL_RED); }
            public void mouseExited(MouseEvent e)  { logoutBtn.setBackground(new Color(127, 29, 29)); }
        });
        logoutBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to log out?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new Index();
            }
        });
        sidebar.add(logoutBtn);

        return sidebar;
    }

    private JButton createNavButton(String label, boolean active) {
        JButton btn = new JButton(label);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setForeground(active ? Color.WHITE : new Color(148, 163, 184));
        btn.setBackground(active ? ACTIVE_BTN : SIDEBAR_BG);
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (!active) { btn.setBackground(SIDEBAR_HOVER); btn.setForeground(Color.WHITE); }
            }
            public void mouseExited(MouseEvent e) {
                if (!active) { btn.setBackground(SIDEBAR_BG); btn.setForeground(new Color(148, 163, 184)); }
            }
        });
        return btn;
    }

    // ==============================================
    // MAIN CONTENT
    // ==============================================
    private JScrollPane buildMainContent() {
        JPanel content = new JPanel();
        content.setLayout(null);
        content.setBackground(BODY_BG);
        content.setPreferredSize(new Dimension(1040, 1050));

        // ---- HEADER ----
        JLabel title = new JLabel("Rental Management");
        title.setBounds(30, 24, 500, 30);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(TEXT_DARK);
        content.add(title);

        JLabel subtitle = new JLabel("Manage and book items for clients.");
        subtitle.setBounds(30, 54, 500, 18);
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(TEXT_MUTED);
        content.add(subtitle);

        // ---- STAT CARDS (matches HTML statistics section) ----
        content.add(buildStatCard("Total Items",       "0",     COL_PURPLE, "▤",  30,  90));
        content.add(buildStatCard("Active Customers",  "0",     COL_GREEN,  "◉", 270,  90));
        content.add(buildStatCard("Total Bookings",    "0",     COL_YELLOW, "◫", 510,  90));
        content.add(buildStatCard("Total Revenue",     "₱0.00", COL_BLUE,   "₱", 750,  90));

        // ---- FILTER BAR ----
        JPanel filterBar = buildFilterBar();
        filterBar.setBounds(30, 228, 970, 58);
        content.add(filterBar);

        // ---- INVENTORY + SUMMARY ROW ----
        // Left: Inventory panel (col-lg-8 equivalent)
        JPanel inventoryPanel = buildInventoryPanel();
        inventoryPanel.setBounds(30, 304, 635, 200);
        content.add(inventoryPanel);

        // Right: Rental Summary (col-lg-4 equivalent)
        JPanel summaryPanel = buildSummaryPanel();
        summaryPanel.setBounds(680, 304, 320, 310);
        content.add(summaryPanel);

        // ---- ONGOING RENTALS TABLE ----
        content.add(buildSectionLabel("Ongoing Rentals", 30, 624));
        content.add(buildOngoingRentalsTable(30, 652));

        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        return scrollPane;
    }

    // ==============================================
    // STAT CARD  (matches Dashboard.java buildStatCard)
    // ==============================================
    private JPanel buildStatCard(String title, String value, Color accent, String icon, int x, int y) {
        JPanel card = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBounds(x, y, 220, 120);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setBounds(16, 16, 150, 18);
        titleLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        titleLbl.setForeground(TEXT_MUTED);

        JLabel valueLbl = new JLabel(value);
        valueLbl.setBounds(16, 44, 150, 36);
        valueLbl.setFont(new Font("Segoe UI", Font.BOLD, 24));
        valueLbl.setForeground(accent);

        JLabel iconLbl = new JLabel(icon, SwingConstants.CENTER);
        iconLbl.setBounds(162, 14, 44, 44);
        iconLbl.setBackground(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 30));
        iconLbl.setForeground(accent);
        iconLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        iconLbl.setOpaque(true);

        JPanel bar = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(accent);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 4, 4);
                g2.dispose();
            }
        };
        bar.setOpaque(false);
        bar.setBounds(16, 96, 60, 4);

        card.add(titleLbl);
        card.add(valueLbl);
        card.add(iconLbl);
        card.add(bar);
        return card;
    }

    // ==============================================
    // FILTER BAR (matches HTML filter bar)
    // ==============================================
    private JPanel buildFilterBar() {
        JPanel bar = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
                g2.dispose();
            }
        };
        bar.setOpaque(false);

        // Search field
        JTextField search = new JTextField("Search item name...");
        search.setBounds(14, 12, 220, 34);
        search.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        search.setForeground(TEXT_MUTED);
        search.setBorder(BorderFactory.createCompoundBorder(
            new RoundedBorder(10, BORDER_COLOR),
            BorderFactory.createEmptyBorder(4, 10, 4, 10)));
        bar.add(search);

        // Filter pills (All Items, Vehicles, Table/Chairs)
        String[] filters = {"All Items", "Vehicles", "Table/Chairs"};
        int fx = 248;
        for (String f : filters) {
            boolean isFirst = f.equals("All Items");
            JButton pill = new JButton(f);
            pill.setBounds(fx, 12, 110, 34);
            pill.setFocusPainted(false);
            pill.setBorderPainted(false);
            pill.setCursor(new Cursor(Cursor.HAND_CURSOR));
            pill.setFont(new Font("Segoe UI", Font.BOLD, 12));
            if (isFirst) {
                pill.setBackground(ACTIVE_BTN);
                pill.setForeground(Color.WHITE);
            } else {
                pill.setBackground(new Color(241, 245, 249));
                pill.setForeground(TEXT_DARK);
            }
            bar.add(pill);
            fx += 120;
        }

        // Sort By label
        JLabel sortLbl = new JLabel("Sort By:");
        sortLbl.setBounds(640, 18, 55, 22);
        sortLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sortLbl.setForeground(TEXT_MUTED);
        bar.add(sortLbl);

        // Sort dropdown
        String[] sorts = {"Availability", "Price: Low to High", "Price: High to Low"};
        JComboBox<String> sortBox = new JComboBox<>(sorts);
        sortBox.setBounds(698, 12, 180, 34);
        sortBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sortBox.setBackground(new Color(241, 245, 249));
        sortBox.setBorder(BorderFactory.createEmptyBorder());
        bar.add(sortBox);

        return bar;
    }

    // ==============================================
    // INVENTORY PANEL (col-lg-8, empty state)
    // ==============================================
    private JPanel buildInventoryPanel() {
        JPanel panel = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
                g2.dispose();
            }
        };
        panel.setOpaque(false);

        JLabel icon = new JLabel("▤", SwingConstants.CENTER);
        icon.setBounds(0, 50, 635, 36);
        icon.setFont(new Font("Segoe UI", Font.PLAIN, 32));
        icon.setForeground(new Color(148, 163, 184));
        panel.add(icon);

        JLabel msg = new JLabel("No items available in the selected category.", SwingConstants.CENTER);
        msg.setBounds(0, 94, 635, 20);
        msg.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        msg.setForeground(TEXT_MUTED);
        panel.add(msg);

        return panel;
    }

    // ==============================================
    // RENTAL SUMMARY PANEL (col-lg-4)
    // ==============================================
    private JPanel buildSummaryPanel() {
        JPanel card = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
                g2.dispose();
            }
        };
        card.setOpaque(false);

        JLabel heading = new JLabel("Rental Summary");
        heading.setBounds(20, 18, 200, 22);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 15));
        heading.setForeground(TEXT_DARK);
        card.add(heading);

        JLabel noItems = new JLabel("No items selected yet.", SwingConstants.CENTER);
        noItems.setBounds(0, 55, 320, 20);
        noItems.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        noItems.setForeground(TEXT_MUTED);
        card.add(noItems);

        // Divider
        JSeparator div = new JSeparator();
        div.setBounds(20, 130, 280, 1);
        div.setForeground(BORDER_COLOR);
        card.add(div);

        // Tax row
        JLabel taxLbl = new JLabel("Tax (12%)");
        taxLbl.setBounds(20, 142, 140, 20);
        taxLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        taxLbl.setForeground(TEXT_MUTED);
        card.add(taxLbl);

        JLabel taxVal = new JLabel("₱0.00");
        taxVal.setBounds(200, 142, 100, 20);
        taxVal.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        taxVal.setForeground(TEXT_DARK);
        card.add(taxVal);

        // Total row
        JLabel totalLbl = new JLabel("Total Cost");
        totalLbl.setBounds(20, 168, 140, 22);
        totalLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        totalLbl.setForeground(TEXT_DARK);
        card.add(totalLbl);

        JLabel totalVal = new JLabel("₱0.00");
        totalVal.setBounds(190, 165, 110, 26);
        totalVal.setFont(new Font("Segoe UI", Font.BOLD, 16));
        totalVal.setForeground(COL_PURPLE);
        card.add(totalVal);

        // Confirm Booking button
        JButton confirmBtn = new JButton("Confirm Booking");
        confirmBtn.setBounds(20, 212, 280, 40);
        confirmBtn.setFocusPainted(false);
        confirmBtn.setBorderPainted(false);
        confirmBtn.setBackground(COL_PURPLE);
        confirmBtn.setForeground(Color.WHITE);
        confirmBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        confirmBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        confirmBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { confirmBtn.setBackground(new Color(67, 56, 202)); }
            public void mouseExited(MouseEvent e)  { confirmBtn.setBackground(COL_PURPLE); }
        });
        card.add(confirmBtn);

        // Clear All button
        JButton clearBtn = new JButton("Clear All");
        clearBtn.setBounds(20, 260, 280, 36);
        clearBtn.setFocusPainted(false);
        clearBtn.setBorderPainted(false);
        clearBtn.setBackground(new Color(241, 245, 249));
        clearBtn.setForeground(TEXT_MUTED);
        clearBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        clearBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        card.add(clearBtn);

        return card;
    }

    // ==============================================
    // ONGOING RENTALS TABLE
    // ==============================================
    private JScrollPane buildOngoingRentalsTable(int x, int y) {
        String[] cols  = {"Customer", "Item Category", "Rental Dates", "Status", "Actions"};
        String[][] data = {{"—", "—", "—", "—", "—"}};

        DefaultTableModel model = new DefaultTableModel(data, cols) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(model);
        table.setRowHeight(38);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setForeground(TEXT_DARK);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setBackground(CARD_BG);
        table.setSelectionBackground(new Color(238, 242, 255));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 11));
        header.setForeground(TEXT_MUTED);
        header.setBackground(new Color(248, 250, 252));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR));
        header.setPreferredSize(new Dimension(header.getWidth(), 40));

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBounds(x, y, 970, 160);
        scroll.setBorder(new RoundedBorder(12, BORDER_COLOR));
        scroll.getViewport().setBackground(CARD_BG);
        return scroll;
    }

    // ==============================================
    // SECTION LABEL (same as Dashboard.java)
    // ==============================================
    private JLabel buildSectionLabel(String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y, 700, 22);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lbl.setForeground(TEXT_DARK);
        return lbl;
    }

    // ==============================================
    // NAVIGATION (unchanged)
    // ==============================================
    private void navigateTo(String destination) {
        this.dispose();
        switch (destination) {
            case "Dashboard": new Dashboard(); break;
            case "Rentals":   new Rentals();   break;
            case "Inventory": new Inventory(); break;
            case "Customers": new Customers(); break;
            case "Payments":  new Payments();  break;
            case "Settings":  new Settings();  break;
        }
    }

    // ==============================================
    // CUSTOM BORDER HELPERS (same as Dashboard.java)
    // ==============================================
    static class RoundedBorder extends AbstractBorder {
        private int radius;
        private Color color;
        RoundedBorder(int radius, Color color) { this.radius = radius; this.color = color; }
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.drawRoundRect(x, y, w - 1, h - 1, radius, radius);
            g2.dispose();
        }
        public Insets getBorderInsets(Component c) { return new Insets(radius + 1, radius + 1, radius + 1, radius + 1); }
    }

    static class RoundBorder extends AbstractBorder {
        private int arc;
        private Color color;
        RoundBorder(int arc, Color color) { this.arc = arc; this.color = color; }
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.drawOval(x, y, w - 1, h - 1);
            g2.dispose();
        }
    }
}