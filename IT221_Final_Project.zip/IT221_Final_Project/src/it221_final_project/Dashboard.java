package it221_final_project;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.Calendar;

public class Dashboard extends JFrame {

    // ===== COLOR PALETTE (matches HTML reference) =====
    private static final Color SIDEBAR_BG    = new Color(15, 23, 42);
    private static final Color SIDEBAR_HOVER = new Color(30, 41, 59);
    private static final Color ACTIVE_BTN    = new Color(79, 70, 229);
    private static final Color BODY_BG       = new Color(223, 232, 242);
    private static final Color CARD_BG       = Color.WHITE;
    private static final Color BORDER_COLOR  = new Color(238, 242, 246);
    private static final Color TEXT_MUTED    = new Color(100, 116, 139);
    private static final Color TEXT_DARK     = new Color(30, 41, 59);

    private static final Color COL_PURPLE    = new Color(79, 70, 229);
    private static final Color COL_GREEN     = new Color(34, 197, 94);
    private static final Color COL_YELLOW    = new Color(234, 179, 8);
    private static final Color COL_RED       = new Color(239, 68, 68);

    private Calendar cal = Calendar.getInstance();

    public Dashboard() {
        createUI();
    }

    private void createUI() {

        // ================= FRAME =================
        setTitle("EventRides PH | Premium Dashboard");
        setSize(1280, 760);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(BODY_BG);

        add(buildSidebar(), BorderLayout.WEST);
        add(buildMainContent(), BorderLayout.CENTER);

        setVisible(true);
    }

    // ==============================================
    // SIDEBAR
    // ==============================================
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(null);
        sidebar.setPreferredSize(new Dimension(240, 760));
        sidebar.setBackground(SIDEBAR_BG);

        // Brand
        JLabel brand = new JLabel("⬡  EventRides PH");
        brand.setBounds(20, 28, 200, 30);
        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("Segoe UI", Font.BOLD, 16));
        sidebar.add(brand);

        // Divider
        JSeparator sep = new JSeparator();
        sep.setBounds(20, 68, 200, 1);
        sep.setForeground(new Color(30, 41, 59));
        sidebar.add(sep);

        // Nav items
        String[][] menu = {
            {"Dashboard",  "▣"},
            {"Rentals",    "◫"},
            {"Inventory",  "▤"},
            {"Customers",  "◉"},
            {"Payments",   "▦"},
            {"Settings",   "⚙"},
        };

        int y = 90;
        for (String[] item : menu) {
            JButton btn = createNavButton(item[1] + "  " + item[0], item[0].equals("Dashboard"));
            btn.setBounds(16, y, 208, 42);
            String dest = item[0];
            btn.addActionListener(e -> navigateTo(dest));
            sidebar.add(btn);
            y += 50;
        }

        // User card at bottom
        JPanel userCard = new JPanel(null);
        userCard.setBounds(16, 650, 208, 60);
        userCard.setBackground(new Color(30, 41, 59));
        userCard.setBorder(BorderFactory.createLineBorder(new Color(51, 65, 85), 1));

        JLabel avatar = new JLabel("SU", SwingConstants.CENTER);
        avatar.setBounds(10, 10, 38, 38);
        avatar.setBackground(COL_PURPLE);
        avatar.setOpaque(true);
        avatar.setForeground(Color.WHITE);
        avatar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        avatar.setBorder(new RoundBorder(19, new Color(79, 70, 229)));
        userCard.add(avatar);

        JLabel uName = new JLabel("System User");
        uName.setBounds(56, 10, 140, 18);
        uName.setForeground(Color.WHITE);
        uName.setFont(new Font("Segoe UI", Font.BOLD, 12));
        userCard.add(uName);

        JLabel uRole = new JLabel("Administrator");
        uRole.setBounds(56, 30, 140, 16);
        uRole.setForeground(new Color(148, 163, 184));
        uRole.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        userCard.add(uRole);

        sidebar.add(userCard);

        // Logout
        JButton logoutBtn = new JButton("⏻  Log Out");
        logoutBtn.setBounds(16, 620, 208, 38);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorderPainted(false);
        logoutBtn.setBackground(new Color(127, 29, 29));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        logoutBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e)  { logoutBtn.setBackground(COL_RED); }
            public void mouseExited(MouseEvent e)   { logoutBtn.setBackground(new Color(127, 29, 29)); }
        });
        logoutBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to log out?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new Index();
            }
        });
        sidebar.add(logoutBtn);

        return sidebar;
    }

    private JButton createNavButton(String label, boolean active) {
        JButton btn = new JButton(label);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setForeground(active ? Color.WHITE : new Color(148, 163, 184));
        btn.setBackground(active ? ACTIVE_BTN : SIDEBAR_BG);
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (!active) { btn.setBackground(SIDEBAR_HOVER); btn.setForeground(Color.WHITE); }
            }
            public void mouseExited(MouseEvent e) {
                if (!active) { btn.setBackground(SIDEBAR_BG); btn.setForeground(new Color(148, 163, 184)); }
            }
        });
        return btn;
    }

    // ==============================================
    // MAIN CONTENT
    // ==============================================
    private JScrollPane buildMainContent() {
        JPanel content = new JPanel();
        content.setLayout(null);
        content.setBackground(BODY_BG);
        content.setPreferredSize(new Dimension(1040, 1000));

        // ---- HEADER ----
        JLabel title = new JLabel("Quick Overview");
        title.setBounds(30, 24, 400, 30);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(TEXT_DARK);
        content.add(title);

        JLabel subtitle = new JLabel("Real-time status of your rental business");
        subtitle.setBounds(30, 54, 400, 18);
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(TEXT_MUTED);
        content.add(subtitle);

        // ---- STAT CARDS ----
        content.add(buildStatCard("Total Bookings", "0",  COL_PURPLE, "▣", 30,  90));
        content.add(buildStatCard("Revenue",        "₱0", COL_GREEN,  "₱", 270, 90));
        content.add(buildStatCard("Active Now",     "0",  COL_YELLOW, "◎", 510, 90));
        content.add(buildStatCard("Overdue",        "0",  COL_RED,    "⚠", 750, 90));

        // ---- SECTION: RECENT TRANSACTIONS ----
        content.add(buildSectionLabel("Recent Transactions", 30, 240));

        String[] cols  = {"Rental ID", "Item Name", "Client", "Status", "Return Date", "Action"};
        String[][] data = {{"—", "—", "—", "—", "—", "—"}};
        JTable table = buildTable(data, cols);
        JScrollPane tScroll = new JScrollPane(table);
        tScroll.setBounds(30, 268, 970, 140);
        tScroll.setBorder(new RoundedBorder(12, BORDER_COLOR));
        tScroll.getViewport().setBackground(CARD_BG);
        content.add(tScroll);

        // ---- SECTION: CALENDAR ----
        content.add(buildSectionLabel("Rental Calendar  —  " + getMonthYear(), 30, 430));
        content.add(buildCalendar(30, 458));

        // ---- SECTION: TODAY'S SCHEDULE ----
        content.add(buildSectionLabel("Today's Schedule", 680, 430));
        content.add(buildScheduleCard(680, 458));

        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        return scrollPane;
    }

    // ==============================================
    // STAT CARD
    // ==============================================
    private JPanel buildStatCard(String title, String value, Color accent, String icon, int x, int y) {
        JPanel card = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBounds(x, y, 220, 120);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setBounds(16, 16, 150, 18);
        titleLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        titleLbl.setForeground(TEXT_MUTED);

        JLabel valueLbl = new JLabel(value);
        valueLbl.setBounds(16, 44, 150, 36);
        valueLbl.setFont(new Font("Segoe UI", Font.BOLD, 28));
        valueLbl.setForeground(accent);

        // Icon badge
        JLabel iconLbl = new JLabel(icon, SwingConstants.CENTER);
        iconLbl.setBounds(162, 14, 44, 44);
        iconLbl.setBackground(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 30));
        iconLbl.setForeground(accent);
        iconLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        iconLbl.setOpaque(true);

        // Bottom accent bar
        JPanel bar = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(accent);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 4, 4);
                g2.dispose();
            }
        };
        bar.setOpaque(false);
        bar.setBounds(16, 96, 60, 4);

        card.add(titleLbl);
        card.add(valueLbl);
        card.add(iconLbl);
        card.add(bar);
        return card;
    }

    // ==============================================
    // CALENDAR
    // ==============================================
    private JPanel buildCalendar(int x, int y) {
        JPanel wrapper = new JPanel(null);
        wrapper.setBounds(x, y, 620, 290);
        wrapper.setBackground(CARD_BG);
        wrapper.setBorder(new RoundedBorder(14, BORDER_COLOR));

        String[] days = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
        int cellW = 85, cellH = 36;
        for (int i = 0; i < 7; i++) {
            JLabel hdr = new JLabel(days[i], SwingConstants.CENTER);
            hdr.setBounds(i * cellW + 10, 8, cellW, cellH);
            hdr.setFont(new Font("Segoe UI", Font.BOLD, 10));
            hdr.setForeground(TEXT_MUTED);
            wrapper.add(hdr);
        }

        int today = cal.get(Calendar.DAY_OF_MONTH);
        Calendar temp = (Calendar) cal.clone();
        temp.set(Calendar.DAY_OF_MONTH, 1);
        int startDay = temp.get(Calendar.DAY_OF_WEEK) - 1;
        int daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

        int row = 0, col = startDay, day = 1;
        for (int i = 0; i < startDay; i++) {
            col = i;
            JLabel empty = new JLabel("", SwingConstants.CENTER);
            empty.setBounds(col * cellW + 10, 50 + row * cellH, cellW, cellH);
            empty.setForeground(new Color(203, 213, 225));
            empty.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
            wrapper.add(empty);
        }
        col = startDay;
        while (day <= daysInMonth) {
            JLabel cell = new JLabel(String.valueOf(day), SwingConstants.CENTER);
            cell.setBounds(col * cellW + 10, 50 + row * cellH, cellW, cellH);
            cell.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
            if (day == today) {
                cell.setBackground(COL_PURPLE);
                cell.setOpaque(true);
                cell.setForeground(Color.WHITE);
                cell.setFont(new Font("Segoe UI", Font.BOLD, 12));
            } else {
                cell.setForeground(TEXT_DARK);
                cell.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            }
            wrapper.add(cell);
            col++;
            if (col == 7) { col = 0; row++; }
            day++;
        }
        return wrapper;
    }

    // ==============================================
    // TODAY'S SCHEDULE CARD
    // ==============================================
    private JPanel buildScheduleCard(int x, int y) {
        JPanel card = new JPanel(null);
        card.setBounds(x, y, 320, 290);
        card.setBackground(CARD_BG);
        card.setBorder(new RoundedBorder(14, BORDER_COLOR));

        JLabel icon = new JLabel("📅", SwingConstants.CENTER);
        icon.setBounds(0, 60, 320, 40);
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));

        JLabel msg = new JLabel("No rentals scheduled for today", SwingConstants.CENTER);
        msg.setBounds(20, 110, 280, 20);
        msg.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        msg.setForeground(TEXT_MUTED);

        card.add(icon);
        card.add(msg);
        return card;
    }

    // ==============================================
    // TABLE
    // ==============================================
    private JTable buildTable(String[][] data, String[] cols) {
        DefaultTableModel model = new DefaultTableModel(data, cols) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(model);
        table.setRowHeight(36);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setForeground(TEXT_DARK);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setBackground(CARD_BG);
        table.setSelectionBackground(new Color(238, 242, 255));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 11));
        header.setForeground(TEXT_MUTED);
        header.setBackground(new Color(252, 253, 254));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR));
        header.setPreferredSize(new Dimension(header.getWidth(), 40));

        return table;
    }

    // ==============================================
    // HELPERS
    // ==============================================
    private JLabel buildSectionLabel(String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y, 700, 22);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lbl.setForeground(TEXT_DARK);
        return lbl;
    }

    private String getMonthYear() {
        String[] months = {"January","February","March","April","May","June",
                           "July","August","September","October","November","December"};
        return months[cal.get(Calendar.MONTH)] + " " + cal.get(Calendar.YEAR);
    }

    // ==============================================
    // NAVIGATION (unchanged)
    // ==============================================
    private void navigateTo(String destination) {
        this.dispose();
        switch (destination) {
            case "Dashboard": new Dashboard(); break;
            case "Rentals":   new Rentals();   break;
            case "Inventory": new Inventory(); break;
            case "Customers": new Customers(); break;
            case "Payments":  new Payments();  break;
            case "Settings":  new Settings();  break;
        }
    }

    // ==============================================
    // CUSTOM BORDER HELPERS
    // ==============================================
    static class RoundedBorder extends AbstractBorder {
        private int radius;
        private Color color;
        RoundedBorder(int radius, Color color) { this.radius = radius; this.color = color; }
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.drawRoundRect(x, y, w-1, h-1, radius, radius);
            g2.dispose();
        }
        public Insets getBorderInsets(Component c) { return new Insets(radius+1, radius+1, radius+1, radius+1); }
    }

    static class RoundBorder extends AbstractBorder {
        private int arc;
        private Color color;
        RoundBorder(int arc, Color color) { this.arc = arc; this.color = color; }
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.drawOval(x, y, w-1, h-1);
            g2.dispose();
        }
    }

    static class setVisible {
        public setVisible(boolean b) {}
    }
}