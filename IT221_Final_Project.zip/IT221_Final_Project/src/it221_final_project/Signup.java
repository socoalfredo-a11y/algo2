package it221_final_project;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class Signup extends JFrame {

    private JTextField     firstName, lastName, business, email;
    private JPasswordField password, confirmPassword;

    // ===== COLOR PALETTE =====
    private static final Color PRIMARY      = new Color(79, 70, 229);
    private static final Color PRIMARY_DARK = new Color(67, 56, 202);
    private static final Color BG_BODY      = new Color(248, 250, 252);
    private static final Color BG_CARD      = Color.WHITE;
    private static final Color TEXT_DARK    = new Color(30, 41, 59);
    private static final Color TEXT_MUTED   = new Color(100, 116, 139);
    private static final Color BORDER_COLOR = new Color(226, 232, 240);
    private static final Color ERROR_COLOR  = new Color(239, 68, 68);

    public Signup() {
        setTitle("Sign Up | EventRides PH");
        setSize(1000, 680);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(1, 2));
        getContentPane().setBackground(BG_BODY);

        add(buildLeftPanel());
        add(buildRightPanel());

        setVisible(true);
    }

    // ==============================================
    // LEFT PANEL — Branding
    // ==============================================
    private JPanel buildLeftPanel() {
        JPanel panel = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, PRIMARY_DARK, getWidth(), getHeight(), PRIMARY);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());

                // Subtle radial overlays
                g2.setColor(new Color(255, 255, 255, 18));
                g2.fillOval(-80, -80, 340, 340);
                g2.setColor(new Color(255, 255, 255, 12));
                g2.fillOval(getWidth() - 200, getHeight() - 200, 320, 320);
                g2.setColor(new Color(255, 255, 255, 8));
                g2.fillOval(getWidth() / 2 - 150, getHeight() / 2 - 150, 300, 300);
                g2.dispose();
            }
        };
        panel.setOpaque(false);

        JLabel icon = new JLabel("🚗", SwingConstants.CENTER);
        icon.setBounds(0, 160, 500, 90);
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 72));

        JLabel brand = new JLabel("EventRides PH", SwingConstants.CENTER);
        brand.setBounds(0, 258, 500, 48);
        brand.setFont(new Font("Segoe UI", Font.BOLD, 34));
        brand.setForeground(Color.WHITE);

        JLabel tagline = new JLabel("Join thousands of event organizers.", SwingConstants.CENTER);
        tagline.setBounds(0, 312, 500, 22);
        tagline.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tagline.setForeground(new Color(255, 255, 255, 175));

        panel.add(icon);
        panel.add(brand);
        panel.add(tagline);
        return panel;
    }

    // ==============================================
    // RIGHT PANEL — Form
    // ==============================================
    private JPanel buildRightPanel() {
        JPanel outer = new JPanel(new GridBagLayout());
        outer.setBackground(BG_BODY);

        JPanel card = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_CARD);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 24, 24);
                g2.setColor(new Color(0, 0, 0, 14));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 24, 24);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setPreferredSize(new Dimension(430, 570));

        int cx = 36;  // left padding
        int cw = 358; // usable width
        int hw = 168; // half width for side-by-side fields

        // --- Back Button ---
        JButton backBtn = new JButton("← Back");
        backBtn.setBounds(cx, 18, 80, 24);
        backBtn.setFocusPainted(false);
        backBtn.setBorderPainted(false);
        backBtn.setContentAreaFilled(false);
        backBtn.setForeground(TEXT_MUTED);
        backBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        backBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { backBtn.setForeground(PRIMARY); }
            public void mouseExited(MouseEvent e)  { backBtn.setForeground(TEXT_MUTED); }
        });
        backBtn.addActionListener(e -> { dispose(); new Index().setVisible(true); });
        card.add(backBtn);

        // --- Title ---
        JLabel title = new JLabel("Create Account", SwingConstants.CENTER);
        title.setBounds(cx, 50, cw, 28);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(TEXT_DARK);
        card.add(title);

        // --- First Name + Last Name (side by side) ---
        card.add(makeLabel("First Name", cx, 94, hw));
        firstName = new JTextField();
        styleField(firstName);
        firstName.setBounds(cx, 112, hw, 38);
        card.add(firstName);

        card.add(makeLabel("Last Name", cx + hw + 22, 94, hw));
        lastName = new JTextField();
        styleField(lastName);
        lastName.setBounds(cx + hw + 22, 112, hw, 38);
        card.add(lastName);

        // --- Business Name ---
        card.add(makeLabel("Business Name", cx, 164, cw));
        business = new JTextField();
        styleField(business);
        business.setBounds(cx, 182, cw, 38);
        card.add(business);

        // --- Email ---
        card.add(makeLabel("Email", cx, 234, cw));
        email = new JTextField();
        styleField(email);
        email.setBounds(cx, 252, cw, 38);
        card.add(email);

        // --- Password ---
        card.add(makeLabel("Password", cx, 304, cw));
        password = new JPasswordField();
        styleField(password);
        password.setEchoChar('●');
        password.setBounds(cx, 322, cw, 38);
        card.add(password);

        JButton showPass = makeEyeButton();
        showPass.setBounds(cx + cw - 36, 326, 30, 30);
        showPass.addActionListener(e -> toggleEcho(password, showPass));
        card.add(showPass);

        // --- Confirm Password ---
        card.add(makeLabel("Confirm Password", cx, 374, cw));
        confirmPassword = new JPasswordField();
        styleField(confirmPassword);
        confirmPassword.setEchoChar('●');
        confirmPassword.setBounds(cx, 392, cw, 38);
        card.add(confirmPassword);

        JButton showConfirm = makeEyeButton();
        showConfirm.setBounds(cx + cw - 36, 396, 30, 30);
        showConfirm.addActionListener(e -> toggleEcho(confirmPassword, showConfirm));
        card.add(showConfirm);

        // --- Error Label ---
        JLabel errorLbl = new JLabel("");
        errorLbl.setBounds(cx, 434, cw, 18);
        errorLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        errorLbl.setForeground(ERROR_COLOR);
        card.add(errorLbl);

        // --- Get Started Button ---
        JButton signupBtn = new JButton("Get Started");
        signupBtn.setBounds(cx, 456, cw, 46);
        signupBtn.setBackground(PRIMARY);
        signupBtn.setForeground(Color.WHITE);
        signupBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        signupBtn.setFocusPainted(false);
        signupBtn.setBorderPainted(false);
        signupBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signupBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { signupBtn.setBackground(PRIMARY_DARK); }
            public void mouseExited(MouseEvent e)  { signupBtn.setBackground(PRIMARY); }
        });
        signupBtn.addActionListener(e -> {
            String p1 = new String(password.getPassword());
            String p2 = new String(confirmPassword.getPassword());

            if (firstName.getText().isEmpty() || lastName.getText().isEmpty()
                    || business.getText().isEmpty() || email.getText().isEmpty()
                    || p1.isEmpty() || p2.isEmpty()) {
                errorLbl.setText("⚠  Please fill in all fields.");
                shakeComponent(card);
                return;
            }

            if (!p1.equals(p2)) {
                errorLbl.setText("⚠  Passwords do not match.");
                confirmPassword.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedLineBorder(ERROR_COLOR, 10),
                    BorderFactory.createEmptyBorder(4, 12, 4, 12)
                ));
                shakeComponent(confirmPassword);
                return;
            }

            errorLbl.setText("");
            signupBtn.setText("Creating account...");
            signupBtn.setEnabled(false);

            Timer t = new Timer(1500, ev -> {
                JOptionPane.showMessageDialog(this, "Account Created Successfully! Welcome to EventRides PH.", "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose();
                new Login();
            });
            t.setRepeats(false);
            t.start();
        });
        card.add(signupBtn);

        // --- Already have account row ---
        JPanel loginRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        loginRow.setOpaque(false);
        loginRow.setBounds(cx, 512, cw, 22);

        JLabel already = new JLabel("Already have an account?");
        already.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        already.setForeground(TEXT_MUTED);

        JButton loginLink = new JButton("Log in");
        loginLink.setFont(new Font("Segoe UI", Font.BOLD, 12));
        loginLink.setForeground(PRIMARY);
        loginLink.setFocusPainted(false);
        loginLink.setBorderPainted(false);
        loginLink.setContentAreaFilled(false);
        loginLink.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginLink.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { loginLink.setForeground(PRIMARY_DARK); }
            public void mouseExited(MouseEvent e)  { loginLink.setForeground(PRIMARY); }
        });
        loginLink.addActionListener(e -> { dispose(); new Login(); });

        loginRow.add(already);
        loginRow.add(loginLink);
        card.add(loginRow);

        outer.add(card);
        return outer;
    }

    // ==============================================
    // HELPERS
    // ==============================================
    private JLabel makeLabel(String text, int x, int y, int w) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y, w, 18);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setForeground(TEXT_DARK);
        return lbl;
    }

    private void styleField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setForeground(TEXT_DARK);
        field.setBackground(BG_CARD);
        field.setBorder(BorderFactory.createCompoundBorder(
            new RoundedLineBorder(BORDER_COLOR, 10),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedLineBorder(PRIMARY, 10),
                    BorderFactory.createEmptyBorder(4, 12, 4, 12)
                ));
            }
            public void focusLost(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedLineBorder(BORDER_COLOR, 10),
                    BorderFactory.createEmptyBorder(4, 12, 4, 12)
                ));
            }
        });
    }

    private JButton makeEyeButton() {
        JButton btn = new JButton("👁");
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 13));
        btn.setForeground(TEXT_MUTED);
        return btn;
    }

    private void toggleEcho(JPasswordField field, JButton btn) {
        if (field.getEchoChar() == '●') {
            field.setEchoChar((char) 0);
            btn.setText("🙈");
        } else {
            field.setEchoChar('●');
            btn.setText("👁");
        }
    }

    private void shakeComponent(JComponent comp) {
        Point origin = comp.getLocation();
        int[] offsets = {-8, 8, -6, 6, -4, 4, -2, 2, 0};
        final int[] idx = {0};
        Timer shake = new Timer(28, null);
        shake.addActionListener(e -> {
            if (idx[0] < offsets.length) {
                comp.setLocation(origin.x + offsets[idx[0]], origin.y);
                idx[0]++;
            } else {
                comp.setLocation(origin);
                shake.stop();
            }
        });
        shake.start();
    }

    // ==============================================
    // CUSTOM BORDER
    // ==============================================
    static class RoundedLineBorder extends AbstractBorder {
        private Color color;
        private int radius;
        RoundedLineBorder(Color color, int radius) { this.color = color; this.radius = radius; }
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.drawRoundRect(x, y, w - 1, h - 1, radius, radius);
            g2.dispose();
        }
        public Insets getBorderInsets(Component c) { return new Insets(6, 12, 6, 12); }
    }
}