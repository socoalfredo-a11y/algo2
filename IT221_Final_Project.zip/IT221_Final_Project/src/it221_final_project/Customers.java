package it221_final_project;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

public class Customers extends JFrame {

    // ===== COLOR PALETTE (matches Dashboard.java) =====
    private static final Color SIDEBAR_BG    = new Color(15, 23, 42);
    private static final Color SIDEBAR_HOVER = new Color(30, 41, 59);
    private static final Color ACTIVE_BTN    = new Color(79, 70, 229);
    private static final Color BODY_BG       = new Color(223, 232, 242);
    private static final Color CARD_BG       = Color.WHITE;
    private static final Color BORDER_COLOR  = new Color(238, 242, 246);
    private static final Color TEXT_MUTED    = new Color(100, 116, 139);
    private static final Color TEXT_DARK     = new Color(30, 41, 59);

    private static final Color COL_PURPLE    = new Color(79, 70, 229);
    private static final Color COL_GREEN     = new Color(34, 197, 94);
    private static final Color COL_YELLOW    = new Color(234, 179, 8);
    private static final Color COL_TEAL      = new Color(20, 184, 166);

    public Customers() {
        createUI();
    }

    private void createUI() {
        setTitle("EventRides PH | Customer Management");
        setSize(1280, 760);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(BODY_BG);

        add(buildSidebar(), BorderLayout.WEST);
        add(buildMainContent(), BorderLayout.CENTER);

        setVisible(true);
    }

    // ==============================================
    // SIDEBAR (mirrors Dashboard.java exactly)
    // ==============================================
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(null);
        sidebar.setPreferredSize(new Dimension(240, 760));
        sidebar.setBackground(SIDEBAR_BG);

        // Brand
        JLabel brand = new JLabel("⬡  EventRides PH");
        brand.setBounds(20, 28, 200, 30);
        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("Segoe UI", Font.BOLD, 16));
        sidebar.add(brand);

        // Divider
        JSeparator sep = new JSeparator();
        sep.setBounds(20, 68, 200, 1);
        sep.setForeground(new Color(30, 41, 59));
        sidebar.add(sep);

        // Nav items — "Customers" is the active page
        String[][] menu = {
            {"Dashboard",  "▣"},
            {"Rentals",    "◫"},
            {"Inventory",  "▤"},
            {"Customers",  "◉"},
            {"Payments",   "▦"},
            {"Settings",   "⚙"},
        };

        int y = 90;
        for (String[] item : menu) {
            boolean isActive = item[0].equals("Customers");
            JButton btn = createNavButton(item[1] + "  " + item[0], isActive);
            btn.setBounds(16, y, 208, 42);
            String dest = item[0];
            btn.addActionListener(e -> navigateTo(dest));
            sidebar.add(btn);
            y += 50;
        }

        // User card at bottom
        JPanel userCard = new JPanel(null);
        userCard.setBounds(16, 650, 208, 60);
        userCard.setBackground(new Color(30, 41, 59));
        userCard.setBorder(BorderFactory.createLineBorder(new Color(51, 65, 85), 1));

        JLabel avatar = new JLabel("SU", SwingConstants.CENTER);
        avatar.setBounds(10, 10, 38, 38);
        avatar.setBackground(COL_PURPLE);
        avatar.setOpaque(true);
        avatar.setForeground(Color.WHITE);
        avatar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        userCard.add(avatar);

        JLabel uName = new JLabel("System User");
        uName.setBounds(56, 10, 140, 18);
        uName.setForeground(Color.WHITE);
        uName.setFont(new Font("Segoe UI", Font.BOLD, 12));
        userCard.add(uName);

        JLabel uRole = new JLabel("Administrator");
        uRole.setBounds(56, 30, 140, 16);
        uRole.setForeground(new Color(148, 163, 184));
        uRole.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        userCard.add(uRole);

        sidebar.add(userCard);

        // Logout button
        JButton logoutBtn = new JButton("⏻  Log Out");
        logoutBtn.setBounds(16, 620, 208, 38);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorderPainted(false);
        logoutBtn.setBackground(new Color(127, 29, 29));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        logoutBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { logoutBtn.setBackground(new Color(239, 68, 68)); }
            public void mouseExited(MouseEvent e)  { logoutBtn.setBackground(new Color(127, 29, 29)); }
        });
        logoutBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to log out?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new Index();
            }
        });
        sidebar.add(logoutBtn);

        return sidebar;
    }

    private JButton createNavButton(String label, boolean active) {
        JButton btn = new JButton(label);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setForeground(active ? Color.WHITE : new Color(148, 163, 184));
        btn.setBackground(active ? ACTIVE_BTN : SIDEBAR_BG);
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (!active) { btn.setBackground(SIDEBAR_HOVER); btn.setForeground(Color.WHITE); }
            }
            public void mouseExited(MouseEvent e) {
                if (!active) { btn.setBackground(SIDEBAR_BG); btn.setForeground(new Color(148, 163, 184)); }
            }
        });
        return btn;
    }

    // ==============================================
    // MAIN CONTENT (mirrors HTML reference layout)
    // ==============================================
    private JScrollPane buildMainContent() {
        JPanel content = new JPanel();
        content.setLayout(null);
        content.setBackground(BODY_BG);
        content.setPreferredSize(new Dimension(1040, 880));

        // ---- HEADER ----
        JLabel title = new JLabel("Customer Management");
        title.setBounds(30, 24, 500, 30);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(TEXT_DARK);
        content.add(title);

        JLabel subtitle = new JLabel("Analyze and manage your client database");
        subtitle.setBounds(30, 54, 500, 18);
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(TEXT_MUTED);
        content.add(subtitle);

        // Add Customer button (top-right header area)
        JButton addBtn = new JButton("+ Add Customer");
        addBtn.setBounds(820, 30, 160, 36);
        addBtn.setFocusPainted(false);
        addBtn.setBorderPainted(false);
        addBtn.setBackground(COL_PURPLE);
        addBtn.setForeground(Color.WHITE);
        addBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        addBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        addBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { addBtn.setBackground(new Color(67, 56, 202)); }
            public void mouseExited(MouseEvent e)  { addBtn.setBackground(COL_PURPLE); }
        });
        addBtn.addActionListener(e ->
            JOptionPane.showMessageDialog(this,
                "This will open your Customer Entry Form or Modal.",
                "Add Customer",
                JOptionPane.INFORMATION_MESSAGE));
        content.add(addBtn);

        // ---- STAT CARDS (matches HTML: Total Clients, New this Month, Avg. LTV, Retention) ----
        content.add(buildStatCard("Total Clients",    "0",   COL_PURPLE, "◉",  30,  90));
        content.add(buildStatCard("New this Month",   "0",   COL_GREEN,  "◈",  270, 90));
        content.add(buildStatCard("Avg. Lifetime Val","₱0",  COL_YELLOW, "◆",  510, 90));
        content.add(buildStatCard("Retention Rate",   "0%",  COL_TEAL,   "↺",  750, 90));

        // ---- SECTION: Revenue Chart placeholder + Top Loyal Clients ----
        content.add(buildSectionLabel("Revenue per Customer Segment", 30, 235));

        JPanel chartPanel = buildChartPlaceholder(30, 260, 620, 220);
        content.add(chartPanel);

        content.add(buildSectionLabel("Top Loyal Clients", 670, 235));
        content.add(buildLoyalClientsPanel(670, 260));

        // ---- SECTION: CUSTOMER TABLE ----
        content.add(buildSectionLabel("Customer Directory", 30, 510));

        // Search bar
        JTextField searchField = new JTextField();
        searchField.setBounds(620, 508, 230, 28);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        searchField.setBorder(BorderFactory.createCompoundBorder(
            new Dashboard.RoundedBorder(8, BORDER_COLOR),
            BorderFactory.createEmptyBorder(2, 8, 2, 8)));
        searchField.setForeground(TEXT_DARK);
        searchField.setBackground(CARD_BG);
        searchField.putClientProperty("JTextField.placeholderText", "Search customer...");
        content.add(searchField);

        // Category dropdown
        String[] categories = {"Name", "ID", "Location"};
        JComboBox<String> catBox = new JComboBox<>(categories);
        catBox.setBounds(860, 508, 110, 28);
        catBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        catBox.setBackground(CARD_BG);
        catBox.setForeground(TEXT_DARK);
        content.add(catBox);

        // Table
        String[] cols = {
            "Customer ID", "Full Name", "Contact",
            "Total Rentals", "Total Spent", "Status", "Action"
        };
        String[][] data = {{"—", "—", "—", "—", "—", "—", "—"}};

        JTable table = buildTable(data, cols);

        // Wire search to filter table
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                String text = searchField.getText().trim().toLowerCase();
                TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
                table.setRowSorter(sorter);
                int col = catBox.getSelectedIndex() == 0 ? 1 : (catBox.getSelectedIndex() == 1 ? 0 : 1);
                sorter.setRowFilter(text.isEmpty() ? null : RowFilter.regexFilter("(?i)" + text, col));
            }
        });

        JScrollPane tScroll = new JScrollPane(table);
        tScroll.setBounds(30, 542, 970, 240);
        tScroll.setBorder(new Dashboard.RoundedBorder(12, BORDER_COLOR));
        tScroll.getViewport().setBackground(CARD_BG);
        content.add(tScroll);

        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        return scrollPane;
    }

    // ==============================================
    // STAT CARD (same style as Dashboard)
    // ==============================================
    private JPanel buildStatCard(String title, String value, Color accent, String icon, int x, int y) {
        JPanel card = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBounds(x, y, 220, 120);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setBounds(16, 16, 150, 18);
        titleLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        titleLbl.setForeground(TEXT_MUTED);

        JLabel valueLbl = new JLabel(value);
        valueLbl.setBounds(16, 44, 150, 36);
        valueLbl.setFont(new Font("Segoe UI", Font.BOLD, 28));
        valueLbl.setForeground(accent);

        JLabel iconLbl = new JLabel(icon, SwingConstants.CENTER);
        iconLbl.setBounds(162, 14, 44, 44);
        iconLbl.setBackground(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 30));
        iconLbl.setForeground(accent);
        iconLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        iconLbl.setOpaque(true);

        JPanel bar = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(accent);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 4, 4);
                g2.dispose();
            }
        };
        bar.setOpaque(false);
        bar.setBounds(16, 96, 60, 4);

        card.add(titleLbl);
        card.add(valueLbl);
        card.add(iconLbl);
        card.add(bar);
        return card;
    }

    // ==============================================
    // CHART PLACEHOLDER (Revenue per Segment)
    // ==============================================
    private JPanel buildChartPlaceholder(int x, int y, int w, int h) {
        JPanel panel = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);

                // Draw simple bar chart skeleton
                int[] barHeights = {60, 100, 40, 130, 80, 110};
                String[] labels   = {"Jan","Feb","Mar","Apr","May","Jun"};
                int barW = 46, gap = 20, startX = 40, baseY = getHeight() - 50;
                for (int i = 0; i < barHeights.length; i++) {
                    int bx = startX + i * (barW + gap);
                    // Bar fill
                    g2.setColor(new Color(79, 70, 229, 80));
                    g2.fillRoundRect(bx, baseY - barHeights[i], barW, barHeights[i], 8, 8);
                    // Bar border
                    g2.setColor(COL_PURPLE);
                    g2.drawRoundRect(bx, baseY - barHeights[i], barW, barHeights[i], 8, 8);
                    // Label
                    g2.setColor(TEXT_MUTED);
                    g2.setFont(new Font("Segoe UI", Font.PLAIN, 10));
                    FontMetrics fm = g2.getFontMetrics();
                    g2.drawString(labels[i], bx + (barW - fm.stringWidth(labels[i])) / 2, baseY + 16);
                }
                // Baseline
                g2.setColor(BORDER_COLOR);
                g2.drawLine(30, baseY, getWidth() - 30, baseY);

                g2.dispose();
            }
        };
        panel.setBounds(x, y, w, h);
        panel.setOpaque(false);

        // Period dropdown top-right inside card
        String[] periods = {"Monthly", "Weekly", "Yearly"};
        JComboBox<String> period = new JComboBox<>(periods);
        period.setBounds(w - 120, 12, 100, 26);
        period.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        period.setBackground(CARD_BG);
        panel.add(period);

        JLabel chartTitle = new JLabel("Revenue per Customer Segment");
        chartTitle.setBounds(16, 14, 340, 18);
        chartTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        chartTitle.setForeground(TEXT_DARK);
        panel.add(chartTitle);

        JLabel chartSub = new JLabel("Financial distribution");
        chartSub.setBounds(16, 32, 280, 14);
        chartSub.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        chartSub.setForeground(TEXT_MUTED);
        panel.add(chartSub);

        return panel;
    }

    // ==============================================
    // TOP LOYAL CLIENTS PANEL
    // ==============================================
    private JPanel buildLoyalClientsPanel(int x, int y) {
        JPanel card = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBounds(x, y, 320, 220);

        JLabel cardTitle = new JLabel("Top Loyal Clients");
        cardTitle.setBounds(16, 14, 280, 18);
        cardTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        cardTitle.setForeground(TEXT_DARK);
        card.add(cardTitle);

        // Empty state
        JLabel starIcon = new JLabel("★", SwingConstants.CENTER);
        starIcon.setBounds(0, 60, 320, 30);
        starIcon.setFont(new Font("Segoe UI", Font.PLAIN, 28));
        starIcon.setForeground(new Color(203, 213, 225));

        JLabel emptyMsg = new JLabel("No ranking data available", SwingConstants.CENTER);
        emptyMsg.setBounds(20, 100, 280, 18);
        emptyMsg.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        emptyMsg.setForeground(TEXT_MUTED);

        card.add(starIcon);
        card.add(emptyMsg);
        return card;
    }

    // ==============================================
    // TABLE
    // ==============================================
    private JTable buildTable(String[][] data, String[] cols) {
        DefaultTableModel model = new DefaultTableModel(data, cols) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(model);
        table.setRowHeight(36);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setForeground(TEXT_DARK);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setBackground(CARD_BG);
        table.setSelectionBackground(new Color(238, 242, 255));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 11));
        header.setForeground(TEXT_MUTED);
        header.setBackground(new Color(252, 253, 254));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR));
        header.setPreferredSize(new Dimension(header.getWidth(), 40));

        // Center-align all columns
        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < cols.length; i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(center);
        }

        return table;
    }

    // ==============================================
    // HELPERS
    // ==============================================
    private JLabel buildSectionLabel(String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y, 700, 22);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lbl.setForeground(TEXT_DARK);
        return lbl;
    }

    // ==============================================
    // NAVIGATION (mirrors Dashboard.java exactly)
    // ==============================================
    private void navigateTo(String destination) {
        this.dispose();
        switch (destination) {
            case "Dashboard": new Dashboard(); break;
            case "Rentals":   new Rentals();   break;
            case "Inventory": new Inventory(); break;
            case "Customers": new Customers(); break;
            case "Payments":  new Payments();  break;
            case "Settings":  new Settings();  break;
        }
    }
}