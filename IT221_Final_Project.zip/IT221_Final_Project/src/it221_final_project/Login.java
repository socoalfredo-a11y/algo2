package it221_final_project;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

public class Login extends JFrame {

    private JTextField     emailField;
    private JPasswordField passwordField;

    // ===== COLOR PALETTE =====
    private static final Color PRIMARY      = new Color(79, 70, 229);
    private static final Color PRIMARY_DARK = new Color(67, 56, 202);
    private static final Color BG_BODY      = new Color(248, 250, 252);
    private static final Color BG_CARD      = Color.WHITE;
    private static final Color TEXT_DARK    = new Color(30, 41, 59);
    private static final Color TEXT_MUTED   = new Color(100, 116, 139);
    private static final Color BORDER_COLOR = new Color(226, 232, 240);

    public Login() {
        initUI();
    }

    private void initUI() {
        setTitle("Log In | EventRides PH");
        setSize(1000, 640);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(1, 2));
        getContentPane().setBackground(BG_BODY);

        add(buildLeftPanel());
        add(buildRightPanel());

        setVisible(true);
    }

    // ==============================================
    // LEFT PANEL — Branding
    // ==============================================
    private JPanel buildLeftPanel() {
        JPanel panel = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, PRIMARY_DARK, getWidth(), getHeight(), PRIMARY);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());

                // Subtle radial overlay circles
                g2.setColor(new Color(255, 255, 255, 18));
                g2.fillOval(-80, -80, 340, 340);
                g2.setColor(new Color(255, 255, 255, 12));
                g2.fillOval(getWidth() - 200, getHeight() - 200, 320, 320);
                g2.setColor(new Color(255, 255, 255, 8));
                g2.fillOval(getWidth() / 2 - 150, getHeight() / 2 - 150, 300, 300);
                g2.dispose();
            }
        };
        panel.setOpaque(false);

        // Car icon (emoji substitute)
        JLabel icon = new JLabel("🚗", SwingConstants.CENTER);
        icon.setBounds(0, 140, 500, 90);
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 72));

        JLabel brand = new JLabel("EventRides PH", SwingConstants.CENTER);
        brand.setBounds(0, 240, 500, 50);
        brand.setFont(new Font("Segoe UI", Font.BOLD, 34));
        brand.setForeground(Color.WHITE);

        JLabel tagline = new JLabel("Smart Rental Management", SwingConstants.CENTER);
        tagline.setBounds(0, 296, 500, 24);
        tagline.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tagline.setForeground(new Color(255, 255, 255, 180));

        panel.add(icon);
        panel.add(brand);
        panel.add(tagline);
        return panel;
    }

    // ==============================================
    // RIGHT PANEL — Form
    // ==============================================
    private JPanel buildRightPanel() {
        JPanel outer = new JPanel(new GridBagLayout());
        outer.setBackground(BG_BODY);

        JPanel card = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_CARD);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 24, 24);
                // Drop shadow simulation via border
                g2.setColor(new Color(0, 0, 0, 14));
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 24, 24);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setPreferredSize(new Dimension(420, 480));

        int cx = 36; // left margin inside card
        int cw = 348; // usable width

        // --- Back Button ---
        JButton backBtn = new JButton("← Back");
        backBtn.setBounds(cx, 20, 80, 26);
        backBtn.setFocusPainted(false);
        backBtn.setBorderPainted(false);
        backBtn.setContentAreaFilled(false);
        backBtn.setForeground(TEXT_MUTED);
        backBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        backBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { backBtn.setForeground(PRIMARY); }
            public void mouseExited(MouseEvent e)  { backBtn.setForeground(TEXT_MUTED); }
        });
        backBtn.addActionListener(e -> { dispose(); new Index().setVisible(true); });
        card.add(backBtn);

        // --- Title ---
        JLabel title = new JLabel("Welcome Back", SwingConstants.CENTER);
        title.setBounds(cx, 58, cw, 30);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(TEXT_DARK);
        card.add(title);

        JLabel subtitle = new JLabel("Please enter your details to log in.", SwingConstants.CENTER);
        subtitle.setBounds(cx, 90, cw, 20);
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitle.setForeground(TEXT_MUTED);
        card.add(subtitle);

        // --- Email ---
        card.add(makeLabel("Email Address", cx, 126, cw));

        emailField = new JTextField();
        styleField(emailField);
        emailField.setBounds(cx, 146, cw, 40);
        emailField.putClientProperty("placeholder", "name@company.com");
        card.add(emailField);

        // --- Password label row ---
        JLabel passLabel = makeLabel("Password", cx, 202, 200);
        card.add(passLabel);

        JButton forgotBtn = new JButton("Forgot password?");
        forgotBtn.setBounds(cx + 210, 202, 138, 18);
        forgotBtn.setFocusPainted(false);
        forgotBtn.setBorderPainted(false);
        forgotBtn.setContentAreaFilled(false);
        forgotBtn.setForeground(PRIMARY);
        forgotBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        forgotBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        forgotBtn.setHorizontalAlignment(SwingConstants.RIGHT);
        card.add(forgotBtn);

        // --- Password field + toggle ---
        passwordField = new JPasswordField();
        styleField(passwordField);
        passwordField.setBounds(cx, 222, cw, 40);
        passwordField.setEchoChar('●');
        card.add(passwordField);

        JButton showPass = new JButton("👁");
        showPass.setBounds(cx + cw - 38, 226, 32, 32);
        showPass.setFocusPainted(false);
        showPass.setBorderPainted(false);
        showPass.setContentAreaFilled(false);
        showPass.setCursor(new Cursor(Cursor.HAND_CURSOR));
        showPass.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 13));
        showPass.setForeground(TEXT_MUTED);
        showPass.addActionListener(e -> {
            if (passwordField.getEchoChar() == '●') {
                passwordField.setEchoChar((char) 0);
                showPass.setText("🙈");
            } else {
                passwordField.setEchoChar('●');
                showPass.setText("👁");
            }
        });
        card.add(showPass);

        // --- Login Button ---
        JButton loginBtn = new JButton("Log In");
        loginBtn.setBounds(cx, 286, cw, 46);
        loginBtn.setBackground(PRIMARY);
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginBtn.setFocusPainted(false);
        loginBtn.setBorderPainted(false);
        loginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { loginBtn.setBackground(PRIMARY_DARK); }
            public void mouseExited(MouseEvent e)  { loginBtn.setBackground(PRIMARY); }
        });
        loginBtn.addActionListener(e -> {
            String email = emailField.getText().trim();
            String pass  = new String(passwordField.getPassword());

            if (email.isEmpty() || pass.isEmpty()) {
                shakeComponent(card);
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Missing Fields", JOptionPane.WARNING_MESSAGE);
                return;
            }

            loginBtn.setText("Logging in...");
            loginBtn.setEnabled(false);

            Timer t = new Timer(1200, ev -> {
                dispose();
                Dashboard dash = new Dashboard();
                dash.revalidate();
                dash.repaint();
                dash.setVisible(true);
            });
            t.setRepeats(false);
            t.start();
        });
        card.add(loginBtn);

        // --- Sign Up Row ---
        JPanel signupRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        signupRow.setOpaque(false);
        signupRow.setBounds(cx, 348, cw, 24);

        JLabel noAcc = new JLabel("Don't have an account?");
        noAcc.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        noAcc.setForeground(TEXT_MUTED);

        JButton signupBtn = new JButton("Sign up");
        signupBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        signupBtn.setForeground(PRIMARY);
        signupBtn.setFocusPainted(false);
        signupBtn.setBorderPainted(false);
        signupBtn.setContentAreaFilled(false);
        signupBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signupBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { signupBtn.setForeground(PRIMARY_DARK); }
            public void mouseExited(MouseEvent e)  { signupBtn.setForeground(PRIMARY); }
        });
        signupBtn.addActionListener(e -> { dispose(); new Signup().setVisible(true); });

        signupRow.add(noAcc);
        signupRow.add(signupBtn);
        card.add(signupRow);

        outer.add(card);
        return outer;
    }

    // ==============================================
    // HELPERS
    // ==============================================
    private JLabel makeLabel(String text, int x, int y, int w) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y, w, 18);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setForeground(TEXT_DARK);
        return lbl;
    }

    private void styleField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setForeground(TEXT_DARK);
        field.setBackground(BG_CARD);
        field.setBorder(BorderFactory.createCompoundBorder(
            new RoundedLineBorder(BORDER_COLOR, 10),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedLineBorder(PRIMARY, 10),
                    BorderFactory.createEmptyBorder(4, 12, 4, 12)
                ));
            }
            public void focusLost(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedLineBorder(BORDER_COLOR, 10),
                    BorderFactory.createEmptyBorder(4, 12, 4, 12)
                ));
            }
        });
    }

    /** Horizontal shake animation for invalid input */
    private void shakeComponent(JComponent comp) {
        Point origin = comp.getLocation();
        Timer shake = new Timer(30, null);
        int[] offsets = {-8, 8, -6, 6, -4, 4, -2, 2, 0};
        final int[] idx = {0};
        shake.addActionListener(e -> {
            if (idx[0] < offsets.length) {
                comp.setLocation(origin.x + offsets[idx[0]], origin.y);
                idx[0]++;
            } else {
                comp.setLocation(origin);
                shake.stop();
            }
        });
        shake.start();
    }

    // ==============================================
    // CUSTOM BORDER
    // ==============================================
    static class RoundedLineBorder extends AbstractBorder {
        private Color color;
        private int radius;
        RoundedLineBorder(Color color, int radius) { this.color = color; this.radius = radius; }
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.drawRoundRect(x, y, w-1, h-1, radius, radius);
            g2.dispose();
        }
        public Insets getBorderInsets(Component c) { return new Insets(6, 12, 6, 12); }
    }
}