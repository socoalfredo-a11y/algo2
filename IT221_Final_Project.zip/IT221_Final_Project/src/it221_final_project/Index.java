package it221_final_project;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

public class Index extends JFrame {

    // ===== COLOR PALETTE =====
    private static final Color PRIMARY      = new Color(79, 70, 229);
    private static final Color PRIMARY_DARK = new Color(67, 56, 202);
    private static final Color BG_BODY      = new Color(248, 250, 252);
    private static final Color BG_CARD      = Color.WHITE;
    private static final Color TEXT_DARK    = new Color(30, 41, 59);
    private static final Color TEXT_MUTED   = new Color(100, 116, 139);
    private static final Color BORDER_COLOR = new Color(226, 232, 240);

    public Index() {
        initUI();
    }

    private void initUI() {
        setTitle("EventRides PH | Smart Rental Management");
        setSize(1100, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(BG_BODY);

        add(createNavbar(),      BorderLayout.NORTH);
        add(createScrollBody(),  BorderLayout.CENTER);
        add(createFooter(),      BorderLayout.SOUTH);

        setVisible(true);
    }

    // ==============================================
    // NAVBAR
    // ==============================================
    private JPanel createNavbar() {
        JPanel nav = new JPanel(new BorderLayout());
        nav.setBackground(BG_CARD);
        nav.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR),
            BorderFactory.createEmptyBorder(14, 32, 14, 32)
        ));

        JLabel brand = new JLabel("⬡ EventRides PH");
        brand.setFont(new Font("Segoe UI", Font.BOLD, 20));
        brand.setForeground(PRIMARY);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        right.setBackground(BG_CARD);

        JButton loginBtn  = createOutlineBtn("Login");
        JButton signupBtn = createPrimaryBtn("Sign Up");

        // NAVIGATION (unchanged)
        loginBtn.addActionListener(e -> { dispose(); new Login().setVisible(true); });
        signupBtn.addActionListener(e -> { dispose(); new Signup().setVisible(true); });

        right.add(loginBtn);
        right.add(signupBtn);

        nav.add(brand, BorderLayout.WEST);
        nav.add(right, BorderLayout.EAST);
        return nav;
    }

    // ==============================================
    // SCROLLABLE BODY
    // ==============================================
    private JScrollPane createScrollBody() {
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(BG_BODY);

        body.add(createHeroSection());
        body.add(createFeaturesSection());
        body.add(createAboutSection());
        body.add(createHowItWorksSection());
        body.add(createCTASection());

        JScrollPane scroll = new JScrollPane(body);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        return scroll;
    }

    // ==============================================
    // HERO SECTION
    // ==============================================
    private JPanel createHeroSection() {
        JPanel hero = new JPanel(new GridLayout(1, 2, 40, 0));
        hero.setBackground(BG_BODY);
        hero.setBorder(BorderFactory.createEmptyBorder(70, 50, 60, 50));
        hero.setMaximumSize(new Dimension(Integer.MAX_VALUE, 480));

        // --- LEFT ---
        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setBackground(BG_BODY);

        JLabel badge = new JLabel("⭐ Trusted by local event organizers");
        badge.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        badge.setForeground(PRIMARY);
        badge.setBorder(BorderFactory.createCompoundBorder(
            new RoundedLineBorder(new Color(199, 210, 254), 20),
            BorderFactory.createEmptyBorder(5, 14, 5, 14)
        ));
        badge.setOpaque(true);
        badge.setBackground(new Color(238, 242, 255));
        badge.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel title = new JLabel("<html><div style='width:380px; font-size:22px; font-weight:700; color:#1e293b; line-height:1.3;'>"
            + "Simplify Your Event Rentals with EventRides PH</div></html>");
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel("<html><div style='width:380px; color:#64748b; font-size:13px; line-height:1.6;'>"
            + "Avoid double bookings and track inventory in real-time. Manage vehicles, tables, and chairs with ease using our smart rental dashboard.</div></html>");
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        btnRow.setBackground(BG_BODY);
        btnRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        JButton getStarted = createPrimaryBtn("Get Started");
        JButton loginBtn   = createOutlineBtn("Login to Dashboard");
        getStarted.addActionListener(e -> { dispose(); new Signup().setVisible(true); });
        loginBtn.addActionListener(e -> { dispose(); new Login().setVisible(true); });
        btnRow.add(getStarted);
        btnRow.add(loginBtn);

        // Quick stats strip
        JPanel statsRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 30, 0));
        statsRow.setBackground(BG_BODY);
        statsRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        statsRow.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_COLOR));
        statsRow.add(createMiniStat("0", "Rentals Managed"));
        statsRow.add(createMiniStat("0", "Missed Bookings"));

        left.add(badge);
        left.add(Box.createVerticalStrut(18));
        left.add(title);
        left.add(Box.createVerticalStrut(14));
        left.add(subtitle);
        left.add(Box.createVerticalStrut(22));
        left.add(btnRow);
        left.add(Box.createVerticalStrut(22));
        left.add(statsRow);

        // --- RIGHT: Dashboard Mockup ---
        JPanel mockup = buildDashboardMockup();

        hero.add(left);
        hero.add(mockup);
        return hero;
    }

    private JPanel buildDashboardMockup() {
        JPanel outer = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_CARD);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                g2.dispose();
            }
        };
        outer.setOpaque(false);

        // Traffic lights
        JPanel dots = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        dots.setOpaque(false);
        dots.setBounds(16, 14, 80, 18);
        for (Color c : new Color[]{new Color(239,68,68), new Color(234,179,8), new Color(34,197,94)}) {
            JLabel d = new JLabel();
            d.setPreferredSize(new Dimension(12, 12));
            d.setBackground(c);
            d.setOpaque(true);
            d.setBorder(new RoundedLineBorder(c.darker(), 6));
            dots.add(d);
        }
        outer.add(dots);

        // Fake search bar
        JPanel search = new JPanel(new BorderLayout());
        search.setBounds(16, 40, 390, 34);
        search.setBackground(new Color(241, 245, 249));
        search.setBorder(new RoundedLineBorder(BORDER_COLOR, 8));
        JLabel searchLbl = new JLabel("  🔍  Search bookings...");
        searchLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        searchLbl.setForeground(TEXT_MUTED);
        search.add(searchLbl, BorderLayout.CENTER);
        outer.add(search);

        // Mini stat cards
        outer.add(buildMockStatCard("Active Bookings", "0", PRIMARY, "📅", 16, 86));
        outer.add(buildMockStatCard("Revenue", "₱0", new Color(34,197,94), "💰", 216, 86));

        // Fake table row
        JPanel row = new JPanel(new BorderLayout());
        row.setBounds(16, 210, 390, 38);
        row.setBackground(new Color(241, 245, 249));
        row.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
        JLabel rowLbl = new JLabel("No bookings yet");
        rowLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        rowLbl.setForeground(TEXT_MUTED);
        JLabel badge2 = new JLabel("Confirmed");
        badge2.setFont(new Font("Segoe UI", Font.BOLD, 10));
        badge2.setForeground(new Color(34,197,94));
        row.add(rowLbl, BorderLayout.WEST);
        row.add(badge2, BorderLayout.EAST);
        outer.add(row);

        return outer;
    }

    private JPanel buildMockStatCard(String title, String val, Color accent, String icon, int x, int y) {
        JPanel card = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 18));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBounds(x, y, 185, 115);

        JLabel iconLbl = new JLabel(icon);
        iconLbl.setBounds(12, 12, 28, 28);
        iconLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 18));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setBounds(12, 46, 160, 16);
        titleLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        titleLbl.setForeground(TEXT_MUTED);

        JLabel valLbl = new JLabel(val);
        valLbl.setBounds(12, 66, 160, 28);
        valLbl.setFont(new Font("Segoe UI", Font.BOLD, 22));
        valLbl.setForeground(accent);

        card.add(iconLbl); card.add(titleLbl); card.add(valLbl);
        return card;
    }

    // ==============================================
    // FEATURES SECTION
    // ==============================================
    private JPanel createFeaturesSection() {
        JPanel section = new JPanel();
        section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS));
        section.setBackground(BG_BODY);
        section.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        section.setMaximumSize(new Dimension(Integer.MAX_VALUE, 380));

        JLabel heading = new JLabel("Everything You Need to Run Your Rentals", SwingConstants.CENTER);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 20));
        heading.setForeground(TEXT_DARK);
        heading.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel sub = new JLabel("A complete suite of tools designed specifically for event rental businesses.", SwingConstants.CENTER);
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(TEXT_MUTED);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel cards = new JPanel(new GridLayout(1, 4, 16, 0));
        cards.setBackground(BG_BODY);
        cards.setAlignmentX(Component.CENTER_ALIGNMENT);

        cards.add(createFeatureCard("🚗", "Vehicle Rentals",    "Track fleet availability, assign drivers, and manage maintenance schedules effortlessly."));
        cards.add(createFeatureCard("🪑", "Tables & Chairs",    "Prevent overbooking with precise inventory counts and package bundling."));
        cards.add(createFeatureCard("📅", "Easy Booking",       "Create, edit, and confirm bookings in seconds through a centralized calendar interface."));
        cards.add(createFeatureCard("💳", "Payment Tracking",   "Monitor downpayments, balances, and generate clear digital invoices for clients."));

        section.add(heading);
        section.add(Box.createVerticalStrut(8));
        section.add(sub);
        section.add(Box.createVerticalStrut(28));
        section.add(cards);
        return section;
    }

    private JPanel createFeatureCard(String icon, String title, String desc) {
        JPanel card = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_CARD);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setPreferredSize(new Dimension(220, 210));

        JLabel iconLbl = new JLabel(icon, SwingConstants.CENTER);
        iconLbl.setBounds(16, 16, 48, 48);
        iconLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 24));
        iconLbl.setBackground(new Color(238, 242, 255));
        iconLbl.setOpaque(true);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setBounds(16, 74, 190, 20);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        titleLbl.setForeground(TEXT_DARK);

        JLabel descLbl = new JLabel("<html><div style='width:180px; color:#64748b; font-size:11px;'>" + desc + "</div></html>");
        descLbl.setBounds(16, 100, 190, 90);

        card.add(iconLbl); card.add(titleLbl); card.add(descLbl);
        return card;
    }

    // ==============================================
    // ABOUT SECTION
    // ==============================================
    private JPanel createAboutSection() {
        JPanel section = new JPanel(new GridLayout(1, 2, 40, 0));
        section.setBackground(BG_CARD);
        section.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 1, 0, BORDER_COLOR),
            BorderFactory.createEmptyBorder(60, 50, 60, 50)
        ));
        section.setMaximumSize(new Dimension(Integer.MAX_VALUE, 360));

        // Left
        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setBackground(BG_CARD);

        JLabel heading = new JLabel("Designed for Efficiency and Growth");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 18));
        heading.setForeground(TEXT_DARK);
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel body = new JLabel("<html><div style='width:380px; color:#64748b; font-size:12px; line-height:1.7;'>"
            + "EventRides PH is a complete rental management system designed to help businesses efficiently manage bookings, "
            + "inventory, and payments. Stop using confusing spreadsheets and switch to a platform built for modern organizers.</div></html>");
        body.setAlignmentX(Component.LEFT_ALIGNMENT);

        String[] checks = {"Real-time inventory tracking", "Organized digital dashboard", "User-friendly interface for your whole team"};
        JPanel checkList = new JPanel();
        checkList.setLayout(new BoxLayout(checkList, BoxLayout.Y_AXIS));
        checkList.setBackground(BG_CARD);
        checkList.setAlignmentX(Component.LEFT_ALIGNMENT);
        for (String c : checks) {
            JLabel item = new JLabel("✔  " + c);
            item.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            item.setForeground(TEXT_DARK);
            item.setAlignmentX(Component.LEFT_ALIGNMENT);
            checkList.add(item);
            checkList.add(Box.createVerticalStrut(10));
        }

        left.add(heading);
        left.add(Box.createVerticalStrut(14));
        left.add(body);
        left.add(Box.createVerticalStrut(20));
        left.add(checkList);

        // Right placeholder
        JPanel right = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(241, 245, 249));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 0, new float[]{6}, 0));
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                g2.dispose();
            }
        };
        right.setOpaque(false);

        JLabel bigIcon = new JLabel("▦", SwingConstants.CENTER);
        bigIcon.setFont(new Font("Segoe UI", Font.PLAIN, 80));
        bigIcon.setForeground(new Color(199, 210, 254));
        bigIcon.setBounds(0, 20, right.getPreferredSize().width, 120);

        JLabel ctlbl = new JLabel("One Dashboard. Total Control.", SwingConstants.CENTER);
        ctlbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        ctlbl.setForeground(TEXT_DARK);
        ctlbl.setBounds(40, 150, 360, 24);

        JLabel ct2 = new JLabel("Access anywhere, from any device.", SwingConstants.CENTER);
        ct2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        ct2.setForeground(TEXT_MUTED);
        ct2.setBounds(40, 180, 360, 20);

        right.add(bigIcon); right.add(ctlbl); right.add(ct2);

        section.add(left);
        section.add(right);
        return section;
    }

    // ==============================================
    // HOW IT WORKS
    // ==============================================
    private JPanel createHowItWorksSection() {
        JPanel section = new JPanel();
        section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS));
        section.setBackground(BG_BODY);
        section.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        section.setMaximumSize(new Dimension(Integer.MAX_VALUE, 360));

        JLabel heading = new JLabel("How It Works", SwingConstants.CENTER);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 20));
        heading.setForeground(TEXT_DARK);
        heading.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel sub = new JLabel("Get your business up and running in three simple steps.", SwingConstants.CENTER);
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(TEXT_MUTED);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel steps = new JPanel(new GridLayout(1, 3, 20, 0));
        steps.setBackground(BG_BODY);
        steps.setAlignmentX(Component.CENTER_ALIGNMENT);

        steps.add(createStepCard("1", "👤", "Register an Account", "Sign up your business in minutes and customize your company profile."));
        steps.add(createStepCard("2", "📦", "Add Your Inventory",   "Input your vehicles, tables, chairs, and set your pricing structures."));
        steps.add(createStepCard("3", "📈", "Manage & Grow",        "Start logging bookings, tracking payments, and growing your event business."));

        section.add(heading);
        section.add(Box.createVerticalStrut(8));
        section.add(sub);
        section.add(Box.createVerticalStrut(28));
        section.add(steps);
        return section;
    }

    private JPanel createStepCard(String num, String icon, String title, String desc) {
        JPanel card = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_CARD);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                g2.dispose();
            }
        };
        card.setOpaque(false);

        // Big background number
        JLabel numLbl = new JLabel(num);
        numLbl.setFont(new Font("Segoe UI", Font.BOLD, 64));
        numLbl.setForeground(new Color(79, 70, 229, 28));
        numLbl.setBounds(130, -8, 100, 80);

        JLabel iconLbl = new JLabel(icon, SwingConstants.CENTER);
        iconLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 24));
        iconLbl.setBackground(new Color(238, 242, 255));
        iconLbl.setOpaque(true);
        iconLbl.setBounds(100, 28, 52, 52);

        JLabel titleLbl = new JLabel(title, SwingConstants.CENTER);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        titleLbl.setForeground(TEXT_DARK);
        titleLbl.setBounds(16, 92, 228, 20);

        JLabel descLbl = new JLabel("<html><div style='text-align:center; width:200px; color:#64748b; font-size:11px;'>" + desc + "</div></html>", SwingConstants.CENTER);
        descLbl.setBounds(16, 118, 228, 60);

        card.add(numLbl); card.add(iconLbl); card.add(titleLbl); card.add(descLbl);
        return card;
    }

    // ==============================================
    // CTA SECTION
    // ==============================================
    private JPanel createCTASection() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(BG_BODY);
        wrapper.setBorder(BorderFactory.createEmptyBorder(20, 50, 40, 50));
        wrapper.setMaximumSize(new Dimension(Integer.MAX_VALUE, 220));

        JPanel cta = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, PRIMARY, getWidth(), getHeight(), PRIMARY_DARK);
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 24, 24);
                g2.dispose();
            }
        };
        cta.setOpaque(false);

        JLabel h = new JLabel("Start Managing Your Rentals Smarter Today", SwingConstants.CENTER);
        h.setFont(new Font("Segoe UI", Font.BOLD, 18));
        h.setForeground(Color.WHITE);
        h.setBounds(0, 28, 1000, 28);

        JLabel s = new JLabel("<html><div style='text-align:center; width:550px; color:rgba(255,255,255,0.8); font-size:12px;'>"
            + "Join local event organizers who have streamlined their operations, reduced errors, and increased revenue.</div></html>",
            SwingConstants.CENTER);
        s.setBounds(225, 66, 550, 40);

        JButton createBtn = new JButton("Create Account");
        createBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        createBtn.setBackground(Color.WHITE);
        createBtn.setForeground(PRIMARY);
        createBtn.setFocusPainted(false);
        createBtn.setBorderPainted(false);
        createBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        createBtn.setPreferredSize(new Dimension(160, 42));
        createBtn.setBounds(420, 116, 160, 42);
        createBtn.addActionListener(e -> { dispose(); new Signup().setVisible(true); });

        cta.add(h); cta.add(s); cta.add(createBtn);
        cta.setPreferredSize(new Dimension(1000, 175));

        wrapper.add(cta, BorderLayout.CENTER);
        return wrapper;
    }

    // ==============================================
    // FOOTER
    // ==============================================
    private JPanel createFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(BG_CARD);
        footer.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_COLOR),
            BorderFactory.createEmptyBorder(14, 32, 14, 32)
        ));

        JLabel left = new JLabel("⬡  EventRides PH");
        left.setFont(new Font("Segoe UI", Font.BOLD, 14));
        left.setForeground(PRIMARY);

        JLabel right = new JLabel("© 2026 EventRides PH. All rights reserved.");
        right.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        right.setForeground(TEXT_MUTED);

        footer.add(left, BorderLayout.WEST);
        footer.add(right, BorderLayout.EAST);
        return footer;
    }

    // ==============================================
    // HELPERS
    // ==============================================
    private JPanel createMiniStat(String value, String label) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(BG_BODY);
        p.setBorder(BorderFactory.createEmptyBorder(12, 0, 0, 0));

        JLabel v = new JLabel(value);
        v.setFont(new Font("Segoe UI", Font.BOLD, 18));
        v.setForeground(TEXT_DARK);
        v.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel l = new JLabel(label);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        l.setForeground(TEXT_MUTED);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);

        p.add(v); p.add(l);
        return p;
    }

    private JButton createPrimaryBtn(String text) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setBackground(PRIMARY);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(150, 38));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(PRIMARY_DARK); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(PRIMARY); }
        });
        return btn;
    }

    private JButton createOutlineBtn(String text) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(BG_CARD);
        btn.setForeground(PRIMARY);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(150, 38));
        btn.setBorder(new RoundedLineBorder(PRIMARY, 8));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(new Color(238, 242, 255)); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(BG_CARD); }
        });
        return btn;
    }

    // ==============================================
    // CUSTOM BORDER
    // ==============================================
    static class RoundedLineBorder extends AbstractBorder {
        private Color color;
        private int radius;
        RoundedLineBorder(Color color, int radius) { this.color = color; this.radius = radius; }
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.drawRoundRect(x, y, w-1, h-1, radius, radius);
            g2.dispose();
        }
        public Insets getBorderInsets(Component c) { return new Insets(4, 8, 4, 8); }
    }
}