package it221_final_project;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

public class Settings extends JFrame {

    // ===== COLOR PALETTE (matches Dashboard.java) =====
    private static final Color SIDEBAR_BG    = new Color(15, 23, 42);
    private static final Color SIDEBAR_HOVER = new Color(30, 41, 59);
    private static final Color ACTIVE_BTN    = new Color(79, 70, 229);
    private static final Color BODY_BG       = new Color(223, 232, 242);
    private static final Color CARD_BG       = Color.WHITE;
    private static final Color BORDER_COLOR  = new Color(238, 242, 246);
    private static final Color TEXT_MUTED    = new Color(100, 116, 139);
    private static final Color TEXT_DARK     = new Color(30, 41, 59);
    private static final Color COL_PURPLE    = new Color(79, 70, 229);
    private static final Color COL_RED       = new Color(239, 68, 68);

    public Settings() {
        createUI();
    }

    private void createUI() {
        setTitle("EventRides PH | Settings");
        setSize(1280, 760);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(BODY_BG);

        add(buildSidebar(), BorderLayout.WEST);
        add(buildMainContent(), BorderLayout.CENTER);

        setVisible(true);
    }

    // ==============================================
    // SIDEBAR (mirrors Dashboard.java exactly)
    // ==============================================
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(null);
        sidebar.setPreferredSize(new Dimension(240, 760));
        sidebar.setBackground(SIDEBAR_BG);

        JLabel brand = new JLabel("⬡  EventRides PH");
        brand.setBounds(20, 28, 200, 30);
        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("Segoe UI", Font.BOLD, 16));
        sidebar.add(brand);

        JSeparator sep = new JSeparator();
        sep.setBounds(20, 68, 200, 1);
        sep.setForeground(new Color(30, 41, 59));
        sidebar.add(sep);

        // Nav items — "Settings" is active
        String[][] menu = {
            {"Dashboard",  "▣"},
            {"Rentals",    "◫"},
            {"Inventory",  "▤"},
            {"Customers",  "◉"},
            {"Payments",   "▦"},
            {"Settings",   "⚙"},
        };

        int y = 90;
        for (String[] item : menu) {
            boolean isActive = item[0].equals("Settings");
            JButton btn = createNavButton(item[1] + "  " + item[0], isActive);
            btn.setBounds(16, y, 208, 42);
            String dest = item[0];
            btn.addActionListener(e -> navigateTo(dest));
            sidebar.add(btn);
            y += 50;
        }

        // User card
        JPanel userCard = new JPanel(null);
        userCard.setBounds(16, 650, 208, 60);
        userCard.setBackground(new Color(30, 41, 59));
        userCard.setBorder(BorderFactory.createLineBorder(new Color(51, 65, 85), 1));

        JLabel avatar = new JLabel("SU", SwingConstants.CENTER);
        avatar.setBounds(10, 10, 38, 38);
        avatar.setBackground(COL_PURPLE);
        avatar.setOpaque(true);
        avatar.setForeground(Color.WHITE);
        avatar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        userCard.add(avatar);

        JLabel uName = new JLabel("System User");
        uName.setBounds(56, 10, 140, 18);
        uName.setForeground(Color.WHITE);
        uName.setFont(new Font("Segoe UI", Font.BOLD, 12));
        userCard.add(uName);

        JLabel uRole = new JLabel("Administrator");
        uRole.setBounds(56, 30, 140, 16);
        uRole.setForeground(new Color(148, 163, 184));
        uRole.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        userCard.add(uRole);

        sidebar.add(userCard);

        // Logout button
        JButton logoutBtn = new JButton("⏻  Log Out");
        logoutBtn.setBounds(16, 620, 208, 38);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorderPainted(false);
        logoutBtn.setBackground(new Color(127, 29, 29));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        logoutBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { logoutBtn.setBackground(COL_RED); }
            public void mouseExited(MouseEvent e)  { logoutBtn.setBackground(new Color(127, 29, 29)); }
        });
        logoutBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to log out?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new Index();
            }
        });
        sidebar.add(logoutBtn);

        return sidebar;
    }

    private JButton createNavButton(String label, boolean active) {
        JButton btn = new JButton(label);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setForeground(active ? Color.WHITE : new Color(148, 163, 184));
        btn.setBackground(active ? ACTIVE_BTN : SIDEBAR_BG);
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (!active) { btn.setBackground(SIDEBAR_HOVER); btn.setForeground(Color.WHITE); }
            }
            public void mouseExited(MouseEvent e) {
                if (!active) { btn.setBackground(SIDEBAR_BG); btn.setForeground(new Color(148, 163, 184)); }
            }
        });
        return btn;
    }

    // ==============================================
    // MAIN CONTENT (mirrors HTML reference layout)
    // ==============================================
    private JScrollPane buildMainContent() {
        JPanel content = new JPanel();
        content.setLayout(null);
        content.setBackground(BODY_BG);
        content.setPreferredSize(new Dimension(1040, 1100));

        // ---- HEADER ----
        JLabel title = new JLabel("System Settings");
        title.setBounds(30, 24, 500, 30);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(TEXT_DARK);
        content.add(title);

        JLabel subtitle = new JLabel("Manage account preferences and business configurations");
        subtitle.setBounds(30, 54, 560, 18);
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(TEXT_MUTED);
        content.add(subtitle);

        // ---- ROW 1: Profile Info (left) + Business Details (right) ----
        content.add(buildProfileCard(30, 90));
        content.add(buildBusinessCard(520, 90));

        // ---- ROW 2: Security + Preferences + Data Management ----
        content.add(buildSecurityCard(30, 400));
        content.add(buildPreferencesCard(360, 400));
        content.add(buildDataManagementCard(690, 400));

        // ---- ROW 3: User Management Table ----
        content.add(buildSectionLabel("User Management", 30, 700));
        JLabel userSub = new JLabel("Manage staff access and permissions");
        userSub.setBounds(30, 722, 400, 16);
        userSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        userSub.setForeground(TEXT_MUTED);
        content.add(userSub);

        JButton addUserBtn = new JButton("+ Add New User");
        addUserBtn.setBounds(830, 706, 150, 32);
        addUserBtn.setFocusPainted(false);
        addUserBtn.setBorderPainted(false);
        addUserBtn.setBackground(COL_PURPLE);
        addUserBtn.setForeground(Color.WHITE);
        addUserBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        addUserBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        addUserBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { addUserBtn.setBackground(new Color(67, 56, 202)); }
            public void mouseExited(MouseEvent e)  { addUserBtn.setBackground(COL_PURPLE); }
        });
        addUserBtn.addActionListener(e ->
            JOptionPane.showMessageDialog(this,
                "This will open the Add New User form.",
                "Add New User",
                JOptionPane.INFORMATION_MESSAGE));
        content.add(addUserBtn);

        content.add(buildUserTable(30, 746));

        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        return scrollPane;
    }

    // ==============================================
    // PROFILE INFORMATION CARD
    // ==============================================
    private JPanel buildProfileCard(int x, int y) {
        JPanel card = buildRoundCard(x, y, 470, 290);

        JLabel cardTitle = new JLabel("Profile Information");
        cardTitle.setBounds(20, 16, 300, 20);
        cardTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        cardTitle.setForeground(TEXT_DARK);
        card.add(cardTitle);

        // Avatar
        JLabel avatarLbl = new JLabel("SU", SwingConstants.CENTER);
        avatarLbl.setBounds(20, 48, 56, 56);
        avatarLbl.setBackground(COL_PURPLE);
        avatarLbl.setOpaque(true);
        avatarLbl.setForeground(Color.WHITE);
        avatarLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        card.add(avatarLbl);

        JButton uploadBtn = new JButton("Upload New");
        uploadBtn.setBounds(86, 62, 110, 28);
        uploadBtn.setFocusPainted(false);
        uploadBtn.setBackground(CARD_BG);
        uploadBtn.setForeground(COL_PURPLE);
        uploadBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        uploadBtn.setBorder(new Dashboard.RoundedBorder(8, COL_PURPLE));
        uploadBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        card.add(uploadBtn);

        // Full Name
        card.add(buildFormLabel("Full Name", 20, 120));
        JTextField nameField = buildFormField("Enter full name", 20, 138, 420);
        card.add(nameField);

        // Email + Phone side by side
        card.add(buildFormLabel("Email Address", 20, 178));
        JTextField emailField = buildFormField("name@example.com", 20, 196, 200);
        card.add(emailField);

        card.add(buildFormLabel("Phone Number", 230, 178));
        JTextField phoneField = buildFormField("+63 000 000 0000", 230, 196, 210);
        card.add(phoneField);

        JButton updateBtn = buildPrimaryButton("Update Profile", 20, 244, 150);
        updateBtn.addActionListener(e ->
            JOptionPane.showMessageDialog(this, "Profile updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE));
        card.add(updateBtn);

        return card;
    }

    // ==============================================
    // BUSINESS DETAILS CARD
    // ==============================================
    private JPanel buildBusinessCard(int x, int y) {
        JPanel card = buildRoundCard(x, y, 470, 290);

        JLabel cardTitle = new JLabel("Business Details");
        cardTitle.setBounds(20, 16, 300, 20);
        cardTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        cardTitle.setForeground(TEXT_DARK);
        card.add(cardTitle);

        card.add(buildFormLabel("Business Name", 20, 50));
        JTextField bNameField = buildFormField("", 20, 68, 420);
        bNameField.setText("EventRides PH");
        card.add(bNameField);

        card.add(buildFormLabel("Address", 20, 108));
        JTextField addressField = buildFormField("Full business address", 20, 126, 420);
        card.add(addressField);

        card.add(buildFormLabel("Contact Email", 20, 166));
        JTextField cEmailField = buildFormField("business@email.com", 20, 184, 200);
        card.add(cEmailField);

        card.add(buildFormLabel("Contact Number", 230, 166));
        JTextField cNumField = buildFormField("Office number", 230, 184, 210);
        card.add(cNumField);

        JButton saveBtn = buildPrimaryButton("Save Business Data", 20, 244, 170);
        saveBtn.addActionListener(e ->
            JOptionPane.showMessageDialog(this, "Business data saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE));
        card.add(saveBtn);

        return card;
    }

    // ==============================================
    // SECURITY CARD
    // ==============================================
    private JPanel buildSecurityCard(int x, int y) {
        JPanel card = buildRoundCard(x, y, 310, 290);

        JLabel cardTitle = new JLabel("Security");
        cardTitle.setBounds(20, 16, 200, 20);
        cardTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        cardTitle.setForeground(TEXT_DARK);
        card.add(cardTitle);

        card.add(buildFormLabel("Current Password", 20, 50));
        JPasswordField curPass = new JPasswordField();
        curPass.setBounds(20, 68, 270, 30);
        curPass.setBackground(new Color(248, 250, 252));
        curPass.setBorder(BorderFactory.createCompoundBorder(
            new Dashboard.RoundedBorder(8, BORDER_COLOR),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        card.add(curPass);

        card.add(buildFormLabel("New Password", 20, 108));
        JPasswordField newPass = new JPasswordField();
        newPass.setBounds(20, 126, 270, 30);
        newPass.setBackground(new Color(248, 250, 252));
        newPass.setBorder(BorderFactory.createCompoundBorder(
            new Dashboard.RoundedBorder(8, BORDER_COLOR),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        card.add(newPass);

        card.add(buildFormLabel("Confirm Password", 20, 166));
        JPasswordField confPass = new JPasswordField();
        confPass.setBounds(20, 184, 270, 30);
        confPass.setBackground(new Color(248, 250, 252));
        confPass.setBorder(BorderFactory.createCompoundBorder(
            new Dashboard.RoundedBorder(8, BORDER_COLOR),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        card.add(confPass);

        // Dark "Update Password" button
        JButton passBtn = new JButton("Update Password");
        passBtn.setBounds(20, 234, 270, 38);
        passBtn.setFocusPainted(false);
        passBtn.setBorderPainted(false);
        passBtn.setBackground(TEXT_DARK);
        passBtn.setForeground(Color.WHITE);
        passBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        passBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        passBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { passBtn.setBackground(new Color(51, 65, 85)); }
            public void mouseExited(MouseEvent e)  { passBtn.setBackground(TEXT_DARK); }
        });
        passBtn.addActionListener(e ->
            JOptionPane.showMessageDialog(this, "Password updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE));
        card.add(passBtn);

        return card;
    }

    // ==============================================
    // PREFERENCES CARD
    // ==============================================
    private JPanel buildPreferencesCard(int x, int y) {
        JPanel card = buildRoundCard(x, y, 310, 290);

        JLabel cardTitle = new JLabel("Preferences");
        cardTitle.setBounds(20, 16, 200, 20);
        cardTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        cardTitle.setForeground(TEXT_DARK);
        card.add(cardTitle);

        // Toggle-style checkboxes
        card.add(buildToggleRow("Enable Notifications", true,  20, 56));
        card.add(buildToggleRow("Dark Mode (Beta)",     false, 20, 96));
        card.add(buildToggleRow("Auto-cloud Backup",    true,  20, 136));

        card.add(buildFormLabel("System Language", 20, 184));

        JComboBox<String> langBox = new JComboBox<>(new String[]{"English (Default)", "Tagalog"});
        langBox.setBounds(20, 202, 270, 32);
        langBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        langBox.setBackground(new Color(248, 250, 252));
        langBox.setForeground(TEXT_DARK);
        langBox.setBorder(new Dashboard.RoundedBorder(8, BORDER_COLOR));
        card.add(langBox);

        return card;
    }

    // ==============================================
    // DATA MANAGEMENT CARD
    // ==============================================
    private JPanel buildDataManagementCard(int x, int y) {
        JPanel card = buildRoundCard(x, y, 290, 290);

        JLabel cardTitle = new JLabel("Data Management");
        cardTitle.setBounds(20, 16, 240, 20);
        cardTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        cardTitle.setForeground(TEXT_DARK);
        card.add(cardTitle);

        JLabel desc = new JLabel("<html>Perform critical system operations<br>and database maintenance.</html>");
        desc.setBounds(20, 42, 250, 36);
        desc.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        desc.setForeground(TEXT_MUTED);
        card.add(desc);

        // Download Backup
        JButton backupBtn = buildOutlineButton("Download Backup (.sql)", 20, 92, 250);
        backupBtn.addActionListener(e ->
            JOptionPane.showMessageDialog(this, "Backup download started.", "Backup", JOptionPane.INFORMATION_MESSAGE));
        card.add(backupBtn);

        // Restore from File
        JButton restoreBtn = buildOutlineButton("Restore from File", 20, 136, 250);
        restoreBtn.addActionListener(e ->
            JOptionPane.showMessageDialog(this, "Select a backup file to restore.", "Restore", JOptionPane.INFORMATION_MESSAGE));
        card.add(restoreBtn);

        // Separator line
        JSeparator hr = new JSeparator();
        hr.setBounds(20, 182, 250, 1);
        hr.setForeground(BORDER_COLOR);
        card.add(hr);

        // Wipe Data — danger button
        JButton wipeBtn = new JButton("Wipe System Data");
        wipeBtn.setBounds(20, 196, 250, 36);
        wipeBtn.setFocusPainted(false);
        wipeBtn.setBorderPainted(false);
        wipeBtn.setBackground(COL_RED);
        wipeBtn.setForeground(Color.WHITE);
        wipeBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        wipeBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        wipeBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { wipeBtn.setBackground(new Color(220, 38, 38)); }
            public void mouseExited(MouseEvent e)  { wipeBtn.setBackground(COL_RED); }
        });
        wipeBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "This will permanently delete all system data. Are you sure?",
                "Confirm Wipe",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION)
                JOptionPane.showMessageDialog(this, "System data wiped.", "Done", JOptionPane.INFORMATION_MESSAGE);
        });
        card.add(wipeBtn);

        return card;
    }

    // ==============================================
    // USER MANAGEMENT TABLE
    // ==============================================
    private JScrollPane buildUserTable(int x, int y) {
        String[] cols = {"User Name", "Role", "Email", "Status", "Action"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        model.addRow(new Object[]{"—", "—", "—", "—", "—"});

        JTable table = new JTable(model);
        table.setRowHeight(36);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setForeground(TEXT_DARK);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setBackground(CARD_BG);
        table.setSelectionBackground(new Color(238, 242, 255));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 11));
        header.setForeground(TEXT_MUTED);
        header.setBackground(new Color(252, 253, 254));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR));
        header.setPreferredSize(new Dimension(header.getWidth(), 40));

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < cols.length; i++)
            table.getColumnModel().getColumn(i).setCellRenderer(center);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBounds(x, y, 970, 160);
        scroll.setBorder(new Dashboard.RoundedBorder(12, BORDER_COLOR));
        scroll.getViewport().setBackground(CARD_BG);
        return scroll;
    }

    // ==============================================
    // HELPERS — rounded card, form fields, buttons
    // ==============================================
    private JPanel buildRoundCard(int x, int y, int w, int h) {
        JPanel card = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBounds(x, y, w, h);
        return card;
    }

    private JLabel buildFormLabel(String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y, 300, 16);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lbl.setForeground(TEXT_MUTED);
        return lbl;
    }

    private JTextField buildFormField(String placeholder, int x, int y, int w) {
        JTextField field = new JTextField();
        field.setBounds(x, y, w, 30);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        field.setBackground(new Color(248, 250, 252));
        field.setForeground(TEXT_DARK);
        field.setBorder(BorderFactory.createCompoundBorder(
            new Dashboard.RoundedBorder(8, BORDER_COLOR),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        if (!placeholder.isEmpty()) {
            field.setToolTipText(placeholder);
            field.putClientProperty("JTextField.placeholderText", placeholder);
        }
        return field;
    }

    private JButton buildPrimaryButton(String label, int x, int y, int w) {
        JButton btn = new JButton(label);
        btn.setBounds(x, y, w, 36);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setBackground(COL_PURPLE);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(new Color(67, 56, 202)); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(COL_PURPLE); }
        });
        return btn;
    }

    private JButton buildOutlineButton(String label, int x, int y, int w) {
        JButton btn = new JButton(label);
        btn.setBounds(x, y, w, 34);
        btn.setFocusPainted(false);
        btn.setBackground(CARD_BG);
        btn.setForeground(COL_PURPLE);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btn.setBorder(new Dashboard.RoundedBorder(8, COL_PURPLE));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(new Color(238, 242, 255)); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(CARD_BG); }
        });
        return btn;
    }

    private JPanel buildToggleRow(String label, boolean checked, int x, int y) {
        JPanel row = new JPanel(null);
        row.setBounds(x, y, 270, 28);
        row.setOpaque(false);

        JCheckBox chk = new JCheckBox(label, checked);
        chk.setBounds(0, 0, 270, 28);
        chk.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        chk.setForeground(TEXT_DARK);
        chk.setOpaque(false);
        chk.setCursor(new Cursor(Cursor.HAND_CURSOR));
        row.add(chk);

        return row;
    }

    private JLabel buildSectionLabel(String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y, 700, 22);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lbl.setForeground(TEXT_DARK);
        return lbl;
    }

    // ==============================================
    // NAVIGATION (mirrors Dashboard.java exactly)
    // ==============================================
    private void navigateTo(String destination) {
        this.dispose();
        switch (destination) {
            case "Dashboard": new Dashboard(); break;
            case "Rentals":   new Rentals();   break;
            case "Inventory": new Inventory(); break;
            case "Customers": new Customers(); break;
            case "Payments":  new Payments();  break;
            case "Settings":  new Settings();  break;
        }
    }
}