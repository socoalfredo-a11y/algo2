package it221_final_project;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

public class Payments extends JFrame {

    // ===== COLOR PALETTE (matches Dashboard.java) =====
    private static final Color SIDEBAR_BG    = new Color(15, 23, 42);
    private static final Color SIDEBAR_HOVER = new Color(30, 41, 59);
    private static final Color ACTIVE_BTN    = new Color(79, 70, 229);
    private static final Color BODY_BG       = new Color(223, 232, 242);
    private static final Color CARD_BG       = Color.WHITE;
    private static final Color BORDER_COLOR  = new Color(238, 242, 246);
    private static final Color TEXT_MUTED    = new Color(100, 116, 139);
    private static final Color TEXT_DARK     = new Color(30, 41, 59);

    private static final Color COL_PURPLE    = new Color(79, 70, 229);
    private static final Color COL_GREEN     = new Color(34, 197, 94);
    private static final Color COL_YELLOW    = new Color(234, 179, 8);
    private static final Color COL_RED       = new Color(239, 68, 68);

    public Payments() {
        createUI();
    }

    private void createUI() {
        setTitle("EventRides PH | Payment Management");
        setSize(1280, 760);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(BODY_BG);

        add(buildSidebar(), BorderLayout.WEST);
        add(buildMainContent(), BorderLayout.CENTER);

        setVisible(true);
    }

    // ==============================================
    // SIDEBAR (mirrors Dashboard.java exactly)
    // ==============================================
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(null);
        sidebar.setPreferredSize(new Dimension(240, 760));
        sidebar.setBackground(SIDEBAR_BG);

        // Brand
        JLabel brand = new JLabel("⬡  EventRides PH");
        brand.setBounds(20, 28, 200, 30);
        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("Segoe UI", Font.BOLD, 16));
        sidebar.add(brand);

        // Divider
        JSeparator sep = new JSeparator();
        sep.setBounds(20, 68, 200, 1);
        sep.setForeground(new Color(30, 41, 59));
        sidebar.add(sep);

        // Nav items — "Payments" is active
        String[][] menu = {
            {"Dashboard",  "▣"},
            {"Rentals",    "◫"},
            {"Inventory",  "▤"},
            {"Customers",  "◉"},
            {"Payments",   "▦"},
            {"Settings",   "⚙"},
        };

        int y = 90;
        for (String[] item : menu) {
            boolean isActive = item[0].equals("Payments");
            JButton btn = createNavButton(item[1] + "  " + item[0], isActive);
            btn.setBounds(16, y, 208, 42);
            String dest = item[0];
            btn.addActionListener(e -> navigateTo(dest));
            sidebar.add(btn);
            y += 50;
        }

        // User card at bottom
        JPanel userCard = new JPanel(null);
        userCard.setBounds(16, 650, 208, 60);
        userCard.setBackground(new Color(30, 41, 59));
        userCard.setBorder(BorderFactory.createLineBorder(new Color(51, 65, 85), 1));

        JLabel avatar = new JLabel("SU", SwingConstants.CENTER);
        avatar.setBounds(10, 10, 38, 38);
        avatar.setBackground(COL_PURPLE);
        avatar.setOpaque(true);
        avatar.setForeground(Color.WHITE);
        avatar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        userCard.add(avatar);

        JLabel uName = new JLabel("System User");
        uName.setBounds(56, 10, 140, 18);
        uName.setForeground(Color.WHITE);
        uName.setFont(new Font("Segoe UI", Font.BOLD, 12));
        userCard.add(uName);

        JLabel uRole = new JLabel("Administrator");
        uRole.setBounds(56, 30, 140, 16);
        uRole.setForeground(new Color(148, 163, 184));
        uRole.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        userCard.add(uRole);

        sidebar.add(userCard);

        // Logout button
        JButton logoutBtn = new JButton("⏻  Log Out");
        logoutBtn.setBounds(16, 620, 208, 38);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorderPainted(false);
        logoutBtn.setBackground(new Color(127, 29, 29));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        logoutBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { logoutBtn.setBackground(COL_RED); }
            public void mouseExited(MouseEvent e)  { logoutBtn.setBackground(new Color(127, 29, 29)); }
        });
        logoutBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to log out?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new Index();
            }
        });
        sidebar.add(logoutBtn);

        return sidebar;
    }

    private JButton createNavButton(String label, boolean active) {
        JButton btn = new JButton(label);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setForeground(active ? Color.WHITE : new Color(148, 163, 184));
        btn.setBackground(active ? ACTIVE_BTN : SIDEBAR_BG);
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (!active) { btn.setBackground(SIDEBAR_HOVER); btn.setForeground(Color.WHITE); }
            }
            public void mouseExited(MouseEvent e) {
                if (!active) { btn.setBackground(SIDEBAR_BG); btn.setForeground(new Color(148, 163, 184)); }
            }
        });
        return btn;
    }

    // ==============================================
    // MAIN CONTENT (mirrors HTML reference layout)
    // ==============================================
    private JScrollPane buildMainContent() {
        JPanel content = new JPanel();
        content.setLayout(null);
        content.setBackground(BODY_BG);
        content.setPreferredSize(new Dimension(1040, 980));

        // ---- HEADER ----
        JLabel title = new JLabel("Payment Transactions");
        title.setBounds(30, 24, 500, 30);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(TEXT_DARK);
        content.add(title);

        JLabel subtitle = new JLabel("Manage billing, collections, and automated receipts");
        subtitle.setBounds(30, 54, 500, 18);
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(TEXT_MUTED);
        content.add(subtitle);

        // Record Payment button
        JButton recordBtn = new JButton("+ Record Payment");
        recordBtn.setBounds(800, 30, 170, 36);
        recordBtn.setFocusPainted(false);
        recordBtn.setBorderPainted(false);
        recordBtn.setBackground(COL_PURPLE);
        recordBtn.setForeground(Color.WHITE);
        recordBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        recordBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        recordBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { recordBtn.setBackground(new Color(67, 56, 202)); }
            public void mouseExited(MouseEvent e)  { recordBtn.setBackground(COL_PURPLE); }
        });
        recordBtn.addActionListener(e -> showRecordPaymentDialog());
        content.add(recordBtn);

        // ---- STAT CARDS (matches HTML: Total Collected, Pending Balance, Security Deposits, Refunds Issued) ----
        content.add(buildStatCard("Total Collected",     "₱0.00", COL_GREEN,  "₱",  30,  90));
        content.add(buildStatCard("Pending Balance",     "₱0.00", COL_PURPLE, "◷",  270, 90));
        content.add(buildStatCard("Security Deposits",   "₱0.00", COL_YELLOW, "⛨",  510, 90));
        content.add(buildStatCard("Refunds Issued",      "₱0.00", COL_RED,    "↩",  750, 90));

        // ---- TRANSACTION TABLE ----
        JLabel tableHeader = new JLabel("Transaction History");
        tableHeader.setBounds(30, 240, 400, 22);
        tableHeader.setFont(new Font("Segoe UI", Font.BOLD, 15));
        tableHeader.setForeground(TEXT_DARK);
        content.add(tableHeader);

        JLabel tableSub = new JLabel("A log of all payments and security deposits.");
        tableSub.setBounds(30, 262, 400, 16);
        tableSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tableSub.setForeground(TEXT_MUTED);
        content.add(tableSub);

        // Search field
        JTextField searchField = new JTextField();
        searchField.setBounds(580, 248, 260, 28);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        searchField.setBorder(BorderFactory.createCompoundBorder(
            new Dashboard.RoundedBorder(8, BORDER_COLOR),
            BorderFactory.createEmptyBorder(2, 8, 2, 8)));
        searchField.setBackground(CARD_BG);
        searchField.setForeground(TEXT_DARK);
        content.add(searchField);

        // Filter button
        JButton filterBtn = new JButton("⊟ Filter");
        filterBtn.setBounds(848, 248, 90, 28);
        filterBtn.setFocusPainted(false);
        filterBtn.setBackground(CARD_BG);
        filterBtn.setForeground(TEXT_MUTED);
        filterBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        filterBtn.setBorder(new Dashboard.RoundedBorder(8, BORDER_COLOR));
        filterBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        content.add(filterBtn);

        // Table columns match the HTML reference exactly
        String[] cols = {"Date", "Transaction ID", "Client", "Reference", "Amount", "Method", "Status", "Receipt"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        model.addRow(new Object[]{"—", "—", "—", "—", "—", "—", "—", "—"});

        JTable table = buildTable(model);

        // Wire search to filter
        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                String text = searchField.getText().trim();
                TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
                table.setRowSorter(sorter);
                sorter.setRowFilter(text.isEmpty() ? null : RowFilter.regexFilter("(?i)" + text));
            }
        });

        JScrollPane tScroll = new JScrollPane(table);
        tScroll.setBounds(30, 288, 970, 180);
        tScroll.setBorder(new Dashboard.RoundedBorder(12, BORDER_COLOR));
        tScroll.getViewport().setBackground(CARD_BG);
        content.add(tScroll);

        // ---- REVENUE TREND CHART + RECENT ACTIVITY ----
        content.add(buildSectionLabel("Revenue Trend", 30, 490));
        content.add(buildRevenueChartPanel(30, 518));

        content.add(buildSectionLabel("Recent Collection Activity", 680, 490));
        content.add(buildRecentActivityPanel(680, 518));

        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        return scrollPane;
    }

    // ==============================================
    // STAT CARD (same style as Dashboard)
    // ==============================================
    private JPanel buildStatCard(String title, String value, Color accent, String icon, int x, int y) {
        JPanel card = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBounds(x, y, 220, 120);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setBounds(16, 16, 150, 18);
        titleLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        titleLbl.setForeground(TEXT_MUTED);

        JLabel valueLbl = new JLabel(value);
        valueLbl.setBounds(16, 44, 160, 36);
        valueLbl.setFont(new Font("Segoe UI", Font.BOLD, 24));
        valueLbl.setForeground(accent);

        JLabel iconLbl = new JLabel(icon, SwingConstants.CENTER);
        iconLbl.setBounds(162, 14, 44, 44);
        iconLbl.setBackground(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 30));
        iconLbl.setForeground(accent);
        iconLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        iconLbl.setOpaque(true);

        JPanel bar = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(accent);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 4, 4);
                g2.dispose();
            }
        };
        bar.setOpaque(false);
        bar.setBounds(16, 96, 60, 4);

        card.add(titleLbl);
        card.add(valueLbl);
        card.add(iconLbl);
        card.add(bar);
        return card;
    }

    // ==============================================
    // REVENUE TREND CHART PANEL
    // ==============================================
    private JPanel buildRevenueChartPanel(int x, int y) {
        JPanel panel = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);

                // Draw bar chart skeleton matching HTML's daily collection chart
                String[] labels = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
                int[] heights   = {0, 0, 0, 0, 0, 0, 0}; // starts at zero like HTML reference
                int barW = 44, gap = 22, startX = 38, baseY = getHeight() - 46;

                // Grid lines
                g2.setColor(new Color(241, 245, 249));
                for (int i = 1; i <= 4; i++) {
                    int lineY = baseY - (i * 35);
                    g2.drawLine(20, lineY, getWidth() - 20, lineY);
                }

                for (int i = 0; i < labels.length; i++) {
                    int bx = startX + i * (barW + gap);
                    int bh = Math.max(heights[i], 4); // min height so bars are visible
                    g2.setColor(new Color(79, 70, 229, 70));
                    g2.fillRoundRect(bx, baseY - bh, barW, bh, 8, 8);
                    g2.setColor(COL_PURPLE);
                    g2.drawRoundRect(bx, baseY - bh, barW, bh, 8, 8);

                    g2.setColor(TEXT_MUTED);
                    g2.setFont(new Font("Segoe UI", Font.PLAIN, 10));
                    FontMetrics fm = g2.getFontMetrics();
                    g2.drawString(labels[i], bx + (barW - fm.stringWidth(labels[i])) / 2, baseY + 16);
                }

                g2.setColor(BORDER_COLOR);
                g2.drawLine(20, baseY, getWidth() - 20, baseY);
                g2.dispose();
            }
        };
        panel.setBounds(x, y, 620, 260);
        panel.setOpaque(false);

        JLabel chartTitle = new JLabel("Daily Collection (₱)");
        chartTitle.setBounds(16, 14, 300, 18);
        chartTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        chartTitle.setForeground(TEXT_DARK);
        panel.add(chartTitle);

        return panel;
    }

    // ==============================================
    // RECENT ACTIVITY PANEL
    // ==============================================
    private JPanel buildRecentActivityPanel(int x, int y) {
        JPanel card = new JPanel(null) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBounds(x, y, 320, 260);

        JLabel cardTitle = new JLabel("Recent Collection Activity");
        cardTitle.setBounds(16, 14, 280, 18);
        cardTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        cardTitle.setForeground(TEXT_DARK);
        card.add(cardTitle);

        // Empty state matching HTML reference
        JLabel emptyMsg = new JLabel("No recent activity detected.", SwingConstants.CENTER);
        emptyMsg.setBounds(20, 100, 280, 18);
        emptyMsg.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        emptyMsg.setForeground(TEXT_MUTED);
        card.add(emptyMsg);

        return card;
    }

    // ==============================================
    // RECORD PAYMENT DIALOG (mirrors HTML modal)
    // ==============================================
    private void showRecordPaymentDialog() {
        JDialog dialog = new JDialog(this, "Record Collection", true);
        dialog.setSize(460, 420);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(null);
        dialog.getContentPane().setBackground(CARD_BG);
        dialog.setUndecorated(false);

        JLabel dlgTitle = new JLabel("Record Collection");
        dlgTitle.setBounds(24, 20, 300, 26);
        dlgTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        dlgTitle.setForeground(TEXT_DARK);
        dialog.add(dlgTitle);

        // Booking reference
        JLabel refLabel = new JLabel("Rental Booking Reference");
        refLabel.setBounds(24, 60, 280, 16);
        refLabel.setFont(new Font("Segoe UI", Font.BOLD, 11));
        refLabel.setForeground(TEXT_MUTED);
        dialog.add(refLabel);

        JComboBox<String> refBox = new JComboBox<>(new String[]{"Select active booking..."});
        refBox.setBounds(24, 78, 400, 34);
        refBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        refBox.setBackground(new Color(248, 250, 252));
        dialog.add(refBox);

        // Amount
        JLabel amtLabel = new JLabel("Amount (₱)");
        amtLabel.setBounds(24, 126, 180, 16);
        amtLabel.setFont(new Font("Segoe UI", Font.BOLD, 11));
        amtLabel.setForeground(TEXT_MUTED);
        dialog.add(amtLabel);

        JTextField amtField = new JTextField("0.00");
        amtField.setBounds(24, 144, 190, 34);
        amtField.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        amtField.setBackground(new Color(248, 250, 252));
        amtField.setBorder(BorderFactory.createCompoundBorder(
            new Dashboard.RoundedBorder(8, BORDER_COLOR),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        dialog.add(amtField);

        // Payment method
        JLabel methodLabel = new JLabel("Payment Method");
        methodLabel.setBounds(234, 126, 180, 16);
        methodLabel.setFont(new Font("Segoe UI", Font.BOLD, 11));
        methodLabel.setForeground(TEXT_MUTED);
        dialog.add(methodLabel);

        JComboBox<String> methodBox = new JComboBox<>(new String[]{"Cash", "GCash", "Bank Transfer"});
        methodBox.setBounds(234, 144, 190, 34);
        methodBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        methodBox.setBackground(new Color(248, 250, 252));
        dialog.add(methodBox);

        // Transaction note
        JLabel noteLabel = new JLabel("Transaction Note");
        noteLabel.setBounds(24, 192, 280, 16);
        noteLabel.setFont(new Font("Segoe UI", Font.BOLD, 11));
        noteLabel.setForeground(TEXT_MUTED);
        dialog.add(noteLabel);

        JTextArea noteArea = new JTextArea("e.g. 50% Downpayment");
        noteArea.setBounds(24, 210, 400, 60);
        noteArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        noteArea.setBackground(new Color(248, 250, 252));
        noteArea.setForeground(TEXT_MUTED);
        noteArea.setLineWrap(true);
        noteArea.setBorder(BorderFactory.createCompoundBorder(
            new Dashboard.RoundedBorder(8, BORDER_COLOR),
            BorderFactory.createEmptyBorder(6, 8, 6, 8)));
        dialog.add(noteArea);

        // Confirm button
        JButton confirmBtn = new JButton("Confirm Payment");
        confirmBtn.setBounds(24, 288, 400, 42);
        confirmBtn.setFocusPainted(false);
        confirmBtn.setBorderPainted(false);
        confirmBtn.setBackground(COL_PURPLE);
        confirmBtn.setForeground(Color.WHITE);
        confirmBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        confirmBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        confirmBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { confirmBtn.setBackground(new Color(67, 56, 202)); }
            public void mouseExited(MouseEvent e)  { confirmBtn.setBackground(COL_PURPLE); }
        });
        confirmBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(dialog,
                "Payment recorded successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);
            dialog.dispose();
        });
        dialog.add(confirmBtn);

        dialog.setVisible(true);
    }

    // ==============================================
    // TABLE
    // ==============================================
    private JTable buildTable(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setRowHeight(36);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setForeground(TEXT_DARK);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setBackground(CARD_BG);
        table.setSelectionBackground(new Color(238, 242, 255));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 11));
        header.setForeground(TEXT_MUTED);
        header.setBackground(new Color(252, 253, 254));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR));
        header.setPreferredSize(new Dimension(header.getWidth(), 40));

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < model.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(center);
        }

        return table;
    }

    // ==============================================
    // HELPERS
    // ==============================================
    private JLabel buildSectionLabel(String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y, 700, 22);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lbl.setForeground(TEXT_DARK);
        return lbl;
    }

    // ==============================================
    // NAVIGATION (mirrors Dashboard.java exactly)
    // ==============================================
    private void navigateTo(String destination) {
        this.dispose();
        switch (destination) {
            case "Dashboard": new Dashboard(); break;
            case "Rentals":   new Rentals();   break;
            case "Inventory": new Inventory(); break;
            case "Customers": new Customers(); break;
            case "Payments":  new Payments();  break;
            case "Settings":  new Settings();  break;
        }
    }
}